<!DOCTYPE html >
  <head>
    <meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
    <meta http-equiv="content-type" content="text/html; charset=UTF-8"/>
    <title>MyTrack</title>
    <style>
      /* Always set the map height explicitly to define the size of the div
       * element that contains the map. */
      #map {
        height: 100%;
      }
      /* Optional: Makes the sample page fill the window. */
      html, body {
        height: 100%;
        margin: 0;
        padding: 0;
      }
    </style>
  </head>

  <body>
    <div id="map"></div>

    <script>

/*    setTimeout(function () {
       window.location.reload();
    }, 5000);
*/

      var customLabel = {
        Historical: {
          label: 'H'
        },
        Temple: {
          label: 'P'
        },
		Science: {
          label: 'S'
        },
		GoldMining: {
          label: 'G'
        }
      };

        function initMap() {
        var map = new google.maps.Map(document.getElementById('map'), {
          center: new google.maps.LatLng(21.7679, 78.8718),
          zoom: 4
        });
        var infoWindow = new google.maps.InfoWindow;

          // Change this depending on the name of your PHP or XML file
		  //Define your own function for loading the file, and call it downloadUrl(). The function takes two parameters:

//1.url specifies the path to either your XML file or to the PHP script that generates the file, depending on whether you want to dynamically update the XML file when your database changes. This map in this tutorial calls a static XML file for the marker data.
	//It is usually easiest to have this XML file reside in the same directory as the HTML file so that you can just refer to it by filename.
//callback indicates the function that the script calls when the XML returns to the JavaScript.
          downloadUrl('http://localhost/PHC-master/google/google_map.php', function(data) {
            var xml = data.responseXML;
            var markers = xml.documentElement.getElementsByTagName('marker');
            Array.prototype.forEach.call(markers, function(markerElem) {
              var id = markerElem.getAttribute('id');
              var name = markerElem.getAttribute('name');
              var age = markerElem.getAttribute('age');
              var sex = markerElem.getAttribute('sex');
                var place = markerElem.getAttribute('place');
              var address = markerElem.getAttribute('address');
              var diag = markerElem.getAttribute('diag');
              var type = markerElem.getAttribute('type');
              var point = new google.maps.LatLng(
                  parseFloat(markerElem.getAttribute('lat')),
                  parseFloat(markerElem.getAttribute('lng')));

                  if(sex==1){
                    sex="Male";
                  }else{
                    sex="Female";
                  }

              var infowincontent = document.createElement('div');

              var strongs = document.createElement('strongs');
              strongs.textContent = 'Name: '+name
              infowincontent.appendChild(strongs);
              infowincontent.appendChild(document.createElement('br'));

              var ag = document.createElement('ag');
              ag.textContent = 'Age: '+age
              infowincontent.appendChild(ag);
              infowincontent.appendChild(document.createElement('br'));

              var sx = document.createElement('sx');
              sx.textContent = 'Sex: '+sex
              infowincontent.appendChild(sx);
              infowincontent.appendChild(document.createElement('br'));

              var text = document.createElement('text');
              text.textContent = 'Address: '+address
              infowincontent.appendChild(text);
			        infowincontent.appendChild(document.createElement('br'));

              var pl = document.createElement('pl');
              pl.textContent = 'Location: '+place
              infowincontent.appendChild(pl);
			        infowincontent.appendChild(document.createElement('br'));


			        var hist = document.createElement('hist');
              hist.textContent ='Diagonosis : '+diag
              infowincontent.appendChild(hist);

              var icon = customLabel[type] || {};
              var marker = new google.maps.Marker({
                map: map,
                position: point,
                label: icon.label
              });
              marker.addListener('click', function() {
                infoWindow.setContent(infowincontent);
                infoWindow.open(map, marker);
              });
            });
          });
        }



      function downloadUrl(url, callback) {
        var request = window.ActiveXObject ?
            new ActiveXObject('Microsoft.XMLHTTP') :
            new XMLHttpRequest;

        request.onreadystatechange = function() {
          if (request.readyState == 4) {
            request.onreadystatechange = doNothing;
            callback(request, request.status);
          }
        };

        request.open('GET', url, true);
        request.send(null);
      }

      function doNothing() {}
    </script>
   <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCbCW52x8CYqkMaKXFtJ1KiIYNu3KZOtKQ&callback=initMap">
    </script>


  </body>
</html>
