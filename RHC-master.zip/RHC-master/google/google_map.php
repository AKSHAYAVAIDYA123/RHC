<?php
$ser="localhost";
	$user="root";
	$pass="";
	$db="medical";
	$conn= mysqli_connect($ser,$user,$pass,$db);

	//Using PHP's DOM functions to output XML

//Below is the PHP file that connects to the MySQL database, and dumps the XML to the browser.
// Start XML file, create parent node
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);

// Opens a connection to a MySQL server
/*$connection=mysql_connect ('localhost', $username, $password);
if (!$connection) {
  die('Not connected : ' . mysql_error());
}
*/
// Set the active MySQL database
/*$db_selected = mysql_select_db($database, $connection);
if (!$db_selected) {
  die ('Can\'t use db : ' . mysql_error());
}
*/
// Select all the rows in the markers table
$res=$conn->query(" select r.drug_id ,date(r.date) as dt,p.pat_no,p.pat_name,p.pat_place,p.age,p.sex,p.pat_lat,p.pat_long,p.pat_addrs , GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.findings separator ',') as find,GROUP_CONCAT(a.drug_name,'-',r.quantity)as drug,GROUP_CONCAT(r.diagonosis separator ',') as diag,GROUP_CONCAT(r.investigation separator ',') as invest,GROUP_CONCAT(r.treatment separator ',') as treat,GROUP_CONCAT(r.reference separator ',') as ref,GROUP_CONCAT(r.complaints separator ',') as compl from patient_record r LEFT OUTER JOIN all_drugs a on a.drug_id=r.drug_id LEFT OUTER JOIN patient_register p on p.pat_no=r.op_fileno  group by date(r.date),r.op_fileno order by r.pat_id desc");
/*$result = mysql_query($query);
if (!$result) {
  die('Invalid query: ' . mysql_error());
}*/

header("Content-type: text/xml");

// Start XML file, echo parent node
/*echo '<markers>';
echo '<marker id="1" name="Billy Kwong" address="1/28 Macleay Street, Elizabeth Bay, NSW" lat="-33.869843" lng="-151.225769" type="restaurant"/>';
echo '<marker id="2" name="Love.Fish" address="580 Darling Street, Rozelle, NSW" lat="-33.861034" lng="151.171936" type="restaurant"/>';
echo '<marker id="3" name="Young Henrys" address="76 Wilford Street, Newtown, NSW" lat="-33.898113" lng="151.174469" type="bar"/>';
echo '<marker id="4" name="Hunter Gatherer" address="Greenwood Plaza, 36 Blue St, North Sydney NSW" lat="-33.840282" lng="151.207474" type="bar"/>';
echo '<marker id="5" name="The Potting Shed" address="7A, 2 Huntley Street, Alexandria, NSW" lat="-33.910751" lng="151.194168" type="bar"/>';
echo '<marker id="6" name="Nomad" address="16 Foster Street, Surry Hills, NSW" lat="-33.879917" lng="151.210449" type="bar"/>';
echo '<marker id="7" name="Three Blue Ducks" address="43 Macpherson Street, Bronte, NSW" lat="-33.906357" lng="151.263763" type="restaurant"/>';
echo '<marker id="8" name="Single Origin Roasters" address="60-64 Reservoir Street, Surry Hills, NSW" lat="-33.881123" lng="151.209656" type="restaurant"/>';
echo '<marker id="9" name="Red Lantern" address="60 Riley Street, Darlinghurst, NSW" lat="-33.874737" lng="151.215530" type="restaurant"/>';
echo '</markers>';*/
$a= 'Temple';

while ($row=@mysqli_fetch_assoc($res)){
// Add to XML document node
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
  $newnode->setAttribute("id",$row['pat_no']);
  $newnode->setAttribute("name",$row['pat_name']);
	$newnode->setAttribute("age", $row['age']);
	$newnode->setAttribute("sex", $row['sex']);
	$newnode->setAttribute("place", $row['pat_place']);
  $newnode->setAttribute("address", $row['pat_addrs']);
	$newnode->setAttribute("diag", $row['diag']);
  $newnode->setAttribute("lat", $row['pat_lat']);
  $newnode->setAttribute("lng", $row['pat_long']);
  $newnode->setAttribute("type", $a);
}

echo $dom->saveXML();

?>
