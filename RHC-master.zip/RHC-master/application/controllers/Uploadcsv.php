<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Uploadcsv extends CI_Controller {

public function __construct()
{
    parent::__construct();
    $this->load->database();
    $this->load->helper('url');
    $this->load->library('session');
     $this->load->model(array('Add_model','Fetch_model','User_model','Update_model','Csv_model'));
}



public function import(){
 if(isset($_POST["import"]))
  {
    if($this->session->userdata('Login')){
  			 $session=$this->session->userdata('Login');
  			 $user['user_id']=$session['id'];
  			 $user['email']=$session['email'];
  			 $user['name']=$session['name'];
  			 $user['role']=$session['role'];
  			 $user['phc_code']=$session['phc_code'];

         					$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
         					$user['warning']=$warn;

         					$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
         					$user['all_warning']=$a_warn;


          $filename=$_FILES["file"]["tmp_name"];
          if($_FILES["file"]["size"] > 0)
          {
            $file = fopen($filename, "r");
            while (($importdata = fgetcsv($file, 10000, ",")) !== FALSE)
            {
                  $data = array(
                      'drug_name' => $importdata[0],
                      'quantity' =>$importdata[1],
                      'measure'  =>$importdata[2],
                      'date_add' => date('Y-m-d h:i:s'),
                      'phc_code' =>$user['phc_code'],
                      'expr_date' =>$importdata[3]
                      );
                      $insert = $this->Csv_model->insertCSV($data);
            }
          fclose($file);
          ?><script>alert("Added Successfully");</script><?php
          		//redirect('Myhome/drugs_add','refresh');
              redirect('Myhome/modify_drugs','refresh');
          }else{
          ?><script>alert("Failed..PLease Try Again");</script><?php
          		//redirect('Myhome/drugs_add','refresh');
                redirect('Myhome/modify_drugs','refresh');
          }
        }
  }
}

}
