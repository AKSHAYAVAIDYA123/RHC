<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_details extends CI_Controller {


	 public function __construct() {
     parent::__construct();
		 $this->load->database();
		 $this->load->model(array('Add_model','Fetch_model','User_model','Update_model','Csv_model'));
		 $this->load->library('session');
			$this->load->helper('url');
   }

	 public function update_history(){
		 if(isset($_POST['submit']) && !empty($_POST['submit'])){
			 if($this->session->userdata('Login')){
						 $session=$this->session->userdata('Login');
						 $user['user_id']=$session['id'];
						 $user['email']=$session['email'];
						 $user['name']=$session['name'];
						 $user['role']=$session['role'];
						 $user['phc_code']=$session['phc_code'];
						 $pat_id =  $this->input->post('pat_id');
						 $data = array(
								 'complaints' => $this->input->post('compl'),
								 'findings' => $this->input->post('find'),
								 'diagonosis' => $this->input->post('diag'),
								 'investigation' => $this->input->post('invest'),
								 'treatment' => $this->input->post('treat')

					 );

					 $result=$this->Update_model->update_history($data,$pat_id);

					 if($result==1){?>
						 <script type="text/javascript">
	                   alert("Updated Successfully...!!");
	          </script><?php
								//redirect('Myhome/phc_add','refresh');
								redirect('Myhome/pat_hist','refresh');
					 }else{?>

						 <script type="text/javascript">
	                   alert("Failed...!!");
	          </script><?php
						//redirect('Myhome/phc_add','refresh');
							redirect('Myhome/pat_hist','refresh');
					 }

				 }else{
					 redirect('/', 'refresh');
				 }

		 }

	 }

	  public function add_phc(){

			if(isset($_POST['submit']) && !empty($_POST['submit'])){
			if($this->session->userdata('Login')){
					 $session=$this->session->userdata('Login');
					 $user['user_id']=$session['id'];
					 $user['email']=$session['email'];
					 $user['name']=$session['name'];
					 $user['role']=$session['role'];
					 $user['phc_code']=$session['phc_code'];
					 $data = array(
							 'phc_name' => $this->input->post('phc_name'),
							 'phc_code' => $this->input->post('phc_code'),
							 'phc_phn' => $this->input->post('phc_phn'),
							 'phc_addr' => $this->input->post('phc_addr')

				 );

				 $result=$this->Add_model->add_phcd($data);

         if($result==1){?>
           <script type="text/javascript">
                   alert("Added Successfully...!!");
          </script><?php
          		//redirect('Myhome/phc_add','refresh');
							redirect('Myhome/modify_phc','refresh');
         }else{?>
           <script type="text/javascript">
                   alert("Failed...!!!");
          </script><?php
          //redirect('Myhome/phc_add','refresh');
					redirect('Myhome/modify_phc','refresh');
         }

			 }else{
				 redirect('/', 'refresh');
			 }

    }
  }

  public function add_doc(){

    if(isset($_POST['submit']) && !empty($_POST['submit'])){
    if($this->session->userdata('Login')){
         $session=$this->session->userdata('Login');
         $user['user_id']=$session['id'];
         $user['email']=$session['email'];
         $user['name']=$session['name'];
				 $user['role']=$session['role'];
				 $user['phc_code']=$session['phc_code'];
         $data = array(

             'doc_name' => $this->input->post('doc_name'),
             'doc_phc' => $this->input->post('doc_phc'),
             'doc_join' => $this->input->post('doc_join'),
             'doc_phone' => $this->input->post('doc_phone'),
						 'doctor_id' => $this->input->post('doc_id')

       );

       $result=$this->Add_model->add_phcdoc($data);
			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;
       if($result==1){?>
         <script type="text/javascript">
                 alert("Added Successfully...!!");
        </script><?php
            redirect('Myhome/doctor_add','refresh');
       }else{?>
         <script type="text/javascript">
                 alert("Failed...!!!");
        </script><?php
        redirect('Myhome/doctor_add','refresh');
       }

     }else{
       redirect('/', 'refresh');
     }

  }
}

public function add_user(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $data = array(

					 'name' => $this->input->post('usr_name'),
					 'email' => $this->input->post('email'),
					 'password' => $this->input->post('pass'),
					 'role' => $this->input->post('role'),
					 'phc_code' => $this->input->post('phc_inch'),
					 'phone' => $this->input->post('phn')

		 );
		 /*warning*/
	 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
	 	$user['warning']=$warn;
	 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
	 	$user['all_warning']=$a_warn;
		 $result=$this->Add_model->add_user($data);

		 if($result==1){?>
			 <script type="text/javascript">
							 alert("Added Successfully...!!");
			</script><?php
					redirect('Myhome/modify_incharge','refresh');
					//redirect('Myhome/user_add','refresh');
		 }else{?>
			 <script type="text/javascript">
							 alert("Failed...!!!");
			</script><?php
			redirect('Myhome/modify_incharge','refresh');
		//	redirect('Myhome/user_add','refresh');
		 }

	 }else{
		 redirect('/', 'refresh');
	 }

}
}


public function add_drug(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
			 $drug_name = $this->input->post('drug_name');
			 $drug_name=array_map('trim',$drug_name);
			 $quantity= $this->input->post('qunt');
		   $phc_code = $this->input->post('phc_code');
			 $exp = $this->input->post('exp');
			 $msr=$this->input->post('msr');
			  $rate=$this->input->post('rate');
			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;

		 for($i=0;$i<count($drug_name);$i++)
		{
		  $data = array('drug_name' =>$drug_name[$i],'quantity' => $quantity[$i],'measure' => $msr[$i],'phc_code' => $phc_code,'expr_date' => $exp[$i],'rate' => $rate[$i]);

		 	$result=$this->Add_model->add_drugs($data);
		}


		 if($result==1){?>
			 <script type="text/javascript">
							 alert("Added Successfully...!!");
			</script><?php
					//redirect('Myhome/drugs_add','refresh');
					  redirect('Myhome/lab_component1','refresh');
		 }else{?>
			 <script type="text/javascript">
							 alert("Failed...!!!");
			</script><?php
			//redirect('Myhome/drugs_add','refresh');
			   redirect('Myhome/lab_component1','refresh');
		 }

	 }else{
		 redirect('/', 'refresh');
	 }
}
}

public function req_drug(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $drug_id = $this->input->post('drug_id');
 		   $cur_quantity= str_replace("-","",$this->input->post('cur_quantity'));
			 $req_quantity = $this->input->post('req_quantity');
			 $month = $this->input->post('month');
			 $phc=$user['phc_code'];

			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;
		 for($i=0;$i<count($drug_id);$i++)
		{
			if($req_quantity[$i]!=0){
				$data = array('drug_id' =>$drug_id[$i],'phc_code'=>$phc,'cur_quantity' => $cur_quantity[$i],'req_quantity'=>$req_quantity[$i],'month_year'=>$month[$i],'status' =>0,'req_name'=>$user['name']);
				$result=$this->Add_model->req_form($data);
			}else{
				$result=1;
			}
		}

		if($result==1){?>
			 <script type="text/javascript">
							 alert("Added Successfully...!!");
			</script><?php
					redirect('Myhome/d_req_pending','refresh');
		 }else{?>
			 <script type="text/javascript">
							 alert("Failed..");
			</script><?php
					redirect('Myhome/d_req_form','refresh');
		 }

	 }else{
		 redirect('/', 'refresh');
	 }

}
}

public function confirm_req_drug(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){

	if($this->session->userdata('Login')){

			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $drug_id = $this->input->post('drug_id');
 		   $cur_quantity= $this->input->post('cur_quantity');
			 $req_quantity = $this->input->post('req_quantity');
			 $month = $this->input->post('month');
			 $hist_id = $this->input->post('hist_id');
			 $phc=$user['phc_code'];
			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;

				for($i=0;$i<count($drug_id);$i++)
						{
							$data = array('drug_id' =>$drug_id[$i],'phc_code'=>$phc,'cur_quantity' => $cur_quantity[$i],'req_quantity'=>$req_quantity[$i],'month_year'=>$month[$i],'status' =>1);
							$result=$this->Add_model->req_confirm($data,$hist_id[$i],$user['phc_code']);
						}
						if($result==1){
							$admin=$this->Add_model->get_admin_email();
							foreach ($admin as $ad) {
							 $this->load->library('My_PHPMailer');
							 $mail = new PHPMailer();
							 $mail->IsSMTP(); // we are going to use SMTP
							 $mail->SMTPAuth   = true; // enabled SMTP authentication
							 $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
							 $mail->Host       = "smtp.gmail.com";      // setting GMail as our SMTP server
							 $mail->Port       = 465;                   // SMTP port to connect to GMail
							 $mail->Username   = "phc.noreply@gmail.com";  // user email address
							 $mail->Password   = "27punithsr";            // password in GMail
							 $mail->SetFrom("phc.noreply@gmail.com","Admin");  //Who is sending the email
							 $mail->AddReplyTo($user['email'],$user['name']);  //email address that receives the response
							 $mail->Subject    = "Drug Request";
							 $mail->Body      = "HTMLfrg message";
							 $mail->AltBody    = "Plain text message";
							 $reciver = $ad['email']; // Who is addressed the email to
							 $mail->AddAddress($reciver, $ad['name']);

							 $mail->AddAttachment("images/phpmailer.gif");      // some attached files
							 $mail->AddAttachment("images/phpmailer_mini.gif"); // as many as you want
							 $mail->Send();
						 }?>
							 <script type="text/javascript">
											 alert("Request Sent Successfully...!!");
							</script><?php
									redirect('Myhome/d_req_form','refresh');
						 }else{?>
							 <script type="text/javascript">
											 alert("Request Sending Failed..");
							</script><?php
									redirect('Myhome/d_req_pending','refresh');
						 }
					 }else{
		 redirect('/', 'refresh');
	 }

}
}

public function add_tests(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){
	if($this->session->userdata('Login')){
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];

			 $test_name = $this->input->post('test_name');
			 $test_name=array_map('trim',$test_name);
			 //$quantity= $this->input->post('qunt');
		   $phc_code = $this->input->post('phc_code');
			 $test_type = $this->input->post('test_type');
			 $test_range = $this->input->post('test_range');
		//	 $exp = $this->input->post('exp');
			// $msr=$this->input->post('msr');

			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;

			 for($i=0;$i<count($test_name);$i++)
			{
			  $data = array('test_type' =>$test_type,'test_name' => $test_name[$i],'phc_code' => $phc_code,'test_range' => $test_range[$i]);

			 	$result=$this->Add_model->add_tests($data);
			}


		 if($result==1){?>
			 <script type="text/javascript">
							 alert("Added Successfully...!!");
			</script><?php
					//redirect('Myhome/drugs_add','refresh');
					  redirect('Myhome/modify_lab_comp','refresh');
		 }else{?>
			 <script type="text/javascript">
							 alert("Failed...!!!");
			</script><?php
			//redirect('Myhome/drugs_add','refresh');
			  redirect('Myhome/modify_lab_comp','refresh');
		 }

	 }else{
		 redirect('/', 'refresh');
	 }
}
}



function index1(){
		$usr=trim($this->input->post('phc_id'));
		$result=$this->Add_model->get_phc_id($usr);
		if($result==true)
		{
			echo "Already Exists...!!";
		}
		else{

		}
 }

 function index2(){
 		$usr=trim($this->input->post('doc_id'));
 	 	$result=$this->Add_model->get_doc_id($usr);
 	 	if($result==true)
 	 	{
 			echo "Already Exists...!!";
 	  }
 	 	else{

 	 	}
  }

	function index3(){
  		$usr=$this->input->post('drug_name');
			$usr=trim($usr);
			$phc=$this->input->post('phc_code');
  	 	$result=$this->Add_model->get_drug($usr,$phc);
  	 	if($result==true)
  	 	{
  			echo "Alredy Drug Name Exists...!!!
				<script>

						$('#id1').hide();
						$('#bt').hide();
						$('#bt1').hide();
  					$('#id').css('border','3px solid red');
				</script>";
  	  }
  	 	else{
				echo "<script> $('#id').css('border','3px solid green');  $('#id1').show();$('#bt').show();$('#bt1').show()</script> ";
  	 	}
   }

	 function index4(){
			 $usr=$this->input->post('keyword');
			 $usr=trim($usr);
			 $rh=$this->input->post('rh');
		 	 $result=$this->Add_model->get_alld($usr,$rh);
			 if($result)
			 {
				 ?>
				 	<ul id="drug-list">
						<?php
					 		foreach ($result as $row) {
					 	?>
							<li onClick="selectDrug('<?php echo $row['drug_name']; ?>','<?php echo $row['drug_id'];?>','<?php echo $row['quantity'];?>','<?php echo $row['measure'];?>');"><?php echo $row['drug_name']; ?></li>
					 <?php
					 }
					?>
				</ul>
				<?php

			} else{
				?>
				 <ul id="drug-list">
 				 		<li>No Results...</li>
					</ul>
			 <?php
			 }
		 }

		 function lab_index(){
		 		$usr=$this->input->post('drug_name');
		 		$usr=trim($usr);
		 		//$phc=$this->input->post('phc_code');
		 		$result=$this->Add_model->get_lab_test($usr);//,$phc);
		 		if($result==true)
		 		{
		 			echo "Alredy Lab Test Name Exists...!!!
		 			<script>

		 					$('#id1').hide();
		 					$('#bt').hide();
		 					$('#bt1').hide();
		 					$('#id').css('border','3px solid red');
		 			</script>";
		 		}
		 		else{
		 			echo "<script> $('#id').css('border','3px solid green');  $('#id1').show();$('#bt').show();$('#bt1').show()</script> ";
		 		}
		  }

//*********Drug stock month & year**************/
		 function drug_stocks(){
			 if($this->session->userdata('Login')){
	 			 $this->load->model('Fetch_model');
	 				$session=$this->session->userdata('Login');
	 				$user['user_id']=$session['id'];
	 				$user['email']=$session['email'];
	 				$user['name']=$session['name'];
	 				$user['role']=$session['role'];
	 				$user['phc_code']=$session['phc_code'];
					$user['title']="Drugs Stock Register";
					$dt=$this->input->post('date');
	 				$m = date("m", strtotime($dt));
	 	 			$y = date("Y", strtotime($dt));

					/*warning*/
					$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
					$user['warning']=$warn;
					$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
					$user['all_warning']=$a_warn;

					$result=$this->Fetch_model->get_stock1($user['phc_code'],$m,$y);
					if(isset($result)&&!empty($result)){

							foreach ($result as $row) {
								?>
								<tr>
											<td><?php echo $row['drug_name']; ?></td>
											<td><?php echo $row['op_bal']; ?></td>
											<td><?php echo $row['usd']; ?></td>
											<td><?php echo $row['req']; ?></td>
											<td><?php echo $row['rec']; ?></td>
											<td><?php echo $row['cl_bal']; ?></td>
								</tr>
								<?php
										}
									}
								}else{
									redirect('/', 'refresh');
								}
		}


		function search_pst(){
			if($this->session->userdata('Login')){
				$this->load->model('Fetch_model');
				 $session=$this->session->userdata('Login');
				 $user['user_id']=$session['id'];
				 $user['email']=$session['email'];
				 $user['name']=$session['name'];
				 $user['role']=$session['role'];
				 $user['phc_code']=$session['phc_code'];
				 $user['title']="Search";

				 $f=$this->input->post('f');
				 $t=$this->input->post('t');
					$g=$this->input->post('g');
				 $a=$this->input->post('a');
				 $trt=$this->input->post('trt');

				 /*warning*/
			 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 	$user['warning']=$warn;
			 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 	$user['all_warning']=$a_warn;

				if($a==18){
						$a1=1;$a2=18;
						$result=$this->Fetch_model->get_otward2($user['phc_code'],$f,$t,$a1,$a2,$g,$trt);
				}else if($a==19){
						$a1=18;$a2=50;
						$result=$this->Fetch_model->get_otward2($user['phc_code'],$f,$t,$a1,$a2,$g,$trt);
				}else if($a==50){
						$a1=50;$a2=100;
							$result=$this->Fetch_model->get_otward2($user['phc_code'],$f,$t,$a1,$a2,$g,$trt);
				}else{
					$result=$this->Fetch_model->get_otward($user['phc_code']);
				}


				 $i=1;
				  $ref_phc=$this->User_model->get_phc();
				 if(isset($result)&&!empty($result)){

						 foreach ($result as $row) {
					 ?>
					 <tr class="danger">
							<th colspan="6">SI No:
							<?php echo $i; ?></th>
					 </tr>
							<tr>
								<th>Date</th>
								<th>Patient ID</th>
								<th>Name</th>
								<th>Age</th>
								 <th>Sex</th>
							</tr>
							<tr>
							 	<td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>
								<td><?php echo $row['pat_no']; ?></td>
							 	<td><?php echo $row['pat_name']; ?></td>
				 		 		<td><?php echo $row['age']; ?></td>
					 			<td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
						</tr>
						<tr>
							 <th>Treatment Type</th>
							 <th>Complaints</th>
							 <th>Findings</th>
							 <th>Diagonosis</th>
							 <th>Investigation</th>
						</tr>
						<tr>
							 <td><p class="break-word"><?php echo $row['visit_type']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['compl']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['find']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['invest']; ?></p></td>
						</tr>
						<tr>
							<th>Treatment</th>
							<th>Reference</th>
							<th colspan="3">Prescription</th>
						</tr>
						<tr>
							 <td><p class="break-word"><?php echo $row['treat']; ?></p></td>
							 <td><p class="break-word">
								 <?php
 							 	foreach($ref_phc as $each){ ?>
											<?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
									<?php } ?>
								 </p></td>
						 	 <td colspan="3"><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>
						 </tr>
						 <style>
						 .break-word {
						 width: 20em;
					 /*  background: lime;*/
					 color:black;

						 overflow-wrap: break-word;
					 }
					 .break-word:hover{
						 font-size: 20px;
						 color:red;

					 }

						 </style>
				 <?php
				 $i++;
					 }
				 }else{
					 ?>
						<tr>
						 <td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
					 </tr>
						<?php
				 }

							 }else{
								 redirect('/', 'refresh');
							 }
	 }
	 //***************************//
	 function med_report_week(){
		 if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['title']="Drugs Stock Register";
				$dt=$this->input->post('date');



				/*warning*/
			 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 $user['warning']=$warn;
			 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 $user['all_warning']=$a_warn;

			 $result=$this->Fetch_model->get_report_medW($user['phc_code'],$dt);

			 $CresultMale=$this->Fetch_model->get_report_medCountD_N_WMale($user['phc_code'],$dt);
			 $CresultFmale=$this->Fetch_model->get_report_medCountD_N_WFmale($user['phc_code'],$dt);

			 $CresultOMale=$this->Fetch_model->get_report_medCountD_O_WMale($user['phc_code'],$dt);
			  $CresultOFmale=$this->Fetch_model->get_report_medCountD_O_WFmale($user['phc_code'],$dt);
				if(isset($result)&&!empty($result)){
						 $i=1;
						foreach ($result as $row) {
							?>
							<tr>
								<td><?php echo $i; ?></td>
								<!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
								<td><?php echo $row['pat_no']; ?></td>
								<td><?php echo $row['pat_name']; ?></td>
								<td><?php echo $row['age']; ?></td>
								<td><?php echo $row['pat_place']; ?></td>
								<td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
								<td><?php if($row['age']>=4){print_r('Child'); }else{ print_r('No');}  ?></td>
								<td><p class="break-word"><?php echo $row['dt']; ?></p></td>
								<td><p class="break-word"><?php echo $row['diag']; ?></p></td>
							<!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
							</tr>
							<?php
								$i++;
									}
									?>
									<tr>
 										<td colspan="8">
 											<table class="examples display table table-striped table-bordered" >
 												<tr>
 													<th>Daily Statistics</th>
 													<th>Male</th>
 													<th>Female</th>
													
 													<th>Total</th>
 												</tr>
 												<tr>
 													<th>New Patients</th>
 													<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 													<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
 													<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
 													
													
													
													<td><?php echo $CresultMale+$CresultFmale; ?></td>
 												</tr>
 												<tr>
 													<th>Old Patients</th>
 													<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 														<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
 														<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
 														<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
 												</tr>
 												<tr>
 													<th>Total</th>
 													<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 													<td><?php echo $CresultMale+$CresultOMale; ?></td>
 													<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
 													<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
 												</tr>
												<tr>
													<th colspan="4">Doctor Name</th>
												</tr>
 											</table>
 										</td>
 							</tr>
									<?php
								}
							 if($result==0){
								 ?>

										<tr>
										 <td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									 </tr>
										<?php
							 }
							}else{
								redirect('/', 'refresh');
							}
	 }


	 //***************************//
	 function med_report_month(){
		 if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['title']="Drugs Stock Register";
				$dt=$this->input->post('date');



				/*warning*/
			 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 $user['warning']=$warn;
			 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 $user['all_warning']=$a_warn;

			 $result=$this->Fetch_model->get_report_medM($user['phc_code'],$dt);

			 $CresultMale=$this->Fetch_model->get_report_medCountD_N_MMale($user['phc_code'],$dt);
			 $CresultFmale=$this->Fetch_model->get_report_medCountD_N_MFmale($user['phc_code'],$dt);

				$CresultOMale=$this->Fetch_model->get_report_medCountD_O_MMale($user['phc_code'],$dt);
				$CresultOFmale=$this->Fetch_model->get_report_medCountD_O_MFmale($user['phc_code'],$dt);
				if(isset($result)&&!empty($result)){
						 $i=1;
						foreach ($result as $row) {
							?>
							<tr>
								<td><?php echo $i; ?></td>
								<!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
								<td><?php echo $row['pat_no']; ?></td>
								<td><?php echo $row['pat_name']; ?></td>
								<td><?php echo $row['age']; ?></td>
								<td><?php echo $row['pat_place']; ?></td>
								<td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
								<td><p class="break-word"><?php echo $row['dt']; ?></p></td>
								<td><p class="break-word"><?php echo $row['diag']; ?></p></td>
							<!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
							</tr>
							<?php
								$i++;
									}
									?>
									<tr>
	 									<td colspan="8">
	 										<table class="examples display table table-striped table-bordered" >
	 											<tr>
	 												<th>Daily Statistics</th>
	 												<th>Male</th>
	 												<th>Female</th>
	 												<th>Total</th>
	 											</tr>
	 											<tr>
	 												<th>New Patients</th>
	 												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
	 												<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
	 												<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
	 												<td><?php echo $CresultMale+$CresultFmale; ?></td>
	 											</tr>
	 											<tr>
	 												<th>Old Patients</th>
	 												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
	 													<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
	 													<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
	 													<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
	 											</tr>
	 											<tr>
	 												<th>Total</th>
	 												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
	 												<td><?php echo $CresultMale+$CresultOMale; ?></td>
	 												<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
	 												<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
	 											</tr>
												<tr>
													<th colspan="4">Doctor Name</th>
												</tr>
	 										</table>
	 									</td>
	 						</tr>
	 						 <?php
								}
							 if($result==0){
								 ?>

										<tr>
										 <td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									 </tr>
										<?php
							 }
							}else{
								redirect('/', 'refresh');
							}
	 }


	 	function med_report_date(){
	 		if($this->session->userdata('Login')){
	 			$this->load->model('Fetch_model');
	 			 $session=$this->session->userdata('Login');
	 			 $user['user_id']=$session['id'];
	 			 $user['email']=$session['email'];
	 			 $user['name']=$session['name'];
	 			 $user['role']=$session['role'];
	 			 $user['phc_code']=$session['phc_code'];
	 			 $user['title']="Drugs Stock Register";
	 			 $dt=$this->input->post('date');

	 			 /*warning*/
	 		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
	 		 	$user['warning']=$warn;
	 		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
	 		 	$user['all_warning']=$a_warn;

				$result=$this->Fetch_model->get_report_med($user['phc_code'],$dt);

				$CresultMale=$this->Fetch_model->get_report_medCountD_NMale($user['phc_code'],$dt);
					$CresultFmale=$this->Fetch_model->get_report_medCountD_NFmale($user['phc_code'],$dt);

				$CresultOMale=$this->Fetch_model->get_report_medCountD_OMale($user['phc_code'],$dt);
					$CresultOFmale=$this->Fetch_model->get_report_medCountD_OFmale($user['phc_code'],$dt);


	 			 if(isset($result)&&!empty($result)){
    	 				$i=1;?>
	 				<?php	 foreach ($result as $row) {
	 						 ?>
							 <tr>
								 <td><?php echo $i; ?></td>
								 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
								 <td><?php echo $row['pat_no']; ?></td>
								 <td><?php echo $row['pat_name']; ?></td>
								 <td><?php echo $row['age']; ?></td>
								 <td><?php echo $row['pat_place']; ?></td>
								 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
							<!--	 <td><p class="break-word"><?php echo $row['visit_type']; ?></p></td>-->
								 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
						<!--		 <td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
							 </tr>
	 						 <?php
							   $i++;
							 }?>
							 <tr>
								 	<td colspan="7">
										<table class="examples display table table-striped table-bordered" >
											<tr>
												<th>Daily Statistics</th>
												<th>Male</th>
												<th>Female</th>
												<th>Total</th>
											</tr>
											<tr>
												<th>New Patients</th>
		 										<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
												<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
												<td><?php echo $CresultMale+$CresultFmale; ?></td>
											</tr>
											<tr>
												<th>Old Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
													<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
													<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
											</tr>
											<tr>
												<th>Total</th>
		 										<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php echo $CresultMale+$CresultOMale; ?></td>
												<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
												<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
											</tr>
											<tr>
												<th colspan="4">Doctor Name</th>
											</tr>
										</table>
									</td>
						</tr>
						 <?php	 }
	 							if($result==0){
	 								?>
	  								 <tr>
	  									<td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
	  								</tr>
	  								 <?php
	 							}
	 						 }else{
	 							 redirect('/', 'refresh');
	 						 }
	  }


	//***************************//
function med_report_date1(){
	 		if($this->session->userdata('Login')){
	 			$this->load->model('Fetch_model');
	 			 $session=$this->session->userdata('Login');
	 			 $user['user_id']=$session['id'];
	 			 $user['email']=$session['email'];
	 			 $user['name']=$session['name'];
	 			 $user['role']=$session['role'];
	 			 $user['phc_code']=$session['phc_code'];
	 			 $user['title']="Drugs Stock Register";
	 			 $dt=$this->input->post('date');

	 			 /*warning*/
	 		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
	 		 	$user['warning']=$warn;
	 		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
	 		 	$user['all_warning']=$a_warn;

				$result=$this->Fetch_model->get_report_med1($user['phc_code'],$dt);
      		 
	//			$CresultOMale=$this->Fetch_model->get_report_med0($user['phc_code'],$dt);
				  
 
	 			 if(isset($result)&&!empty($result)){
    	 				$i=1;?>
	 				<?php	 foreach ($result as $row) {
	 						 ?>
							 <tr>
								 <td><?php echo $i; ?></td>
								<!--<td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
								 <td><?php echo $row['drug_name']; ?></td>
								<td><?php echo $row['op_bal']; ?></td>
								 <td><?php echo $row['cl_bal']; ?></td>
								 <td><?php echo $row['qty_utilised']; ?></td>
								 <td><?php echo $row['cl_rate']; ?></td>
								 <td><?php echo $row['tcost']; ?></td>
								
								
								 
							 </tr>
	 						 <?php
							   $i++;
							 }?>
							 <tr>
								 	<td colspan="7">
										<table class="examples display table table-striped table-bordered" >
										 <th>Total Amount </th>
								  		 <th>   </th>
										</table>
									</td>
						</tr>
						 <?php	 }
	 							if($result==0){
	 								?>
	  								 <tr>
	  									<td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
	  								</tr>
	  								 <?php
	 							}
	 						 }else{
	 							 redirect('/', 'refresh');
	 						 }
	  }

	   function med_report_month1(){
		 if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['title']="Drugs Stock Register";
				$dt=$this->input->post('date');



				/*warning*/
			 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 $user['warning']=$warn;
			 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 $user['all_warning']=$a_warn;

			 $result=$this->Fetch_model->get_report_medM1($user['phc_code'],$dt);

			 
				if(isset($result)&&!empty($result)){
						 $i=1;
						foreach ($result as $row) {
							?>
							<tr>
								<td><?php echo $i; ?></td>
								<!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
									<td><?php echo $row['drug_name']; ?></td>
								<td><?php echo $row['op_bal']; ?></td>
								<td><?php echo $row['cl_bal']; ?></td>
								<td><?php echo $row['qty_utilised']; ?></td>
								 <td><?php echo $row['cl_rate']; ?></td>
								  <td><?php echo $row['tcost']; ?></td>
							 	</tr>
							<?php
								$i++;
									}
									?>
									<tr>
	 									<td colspan="8">
	 										<table class="examples display table table-striped table-bordered" >
	 											<th>Total </th>
	 											<th></th>
	 										</table>
	 									</td>
	 						</tr>
	 						 <?php
								}
							 if($result==0){
								 ?>

										<tr>
										 <td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									 </tr>
										<?php
							 }
							}else{
								redirect('/', 'refresh');
							}
	 }

 function med_report_week1(){
		 if($this->session->userdata('Login')){
			 $this->load->model('Fetch_model');
				$session=$this->session->userdata('Login');
				$user['user_id']=$session['id'];
				$user['email']=$session['email'];
				$user['name']=$session['name'];
				$user['role']=$session['role'];
				$user['phc_code']=$session['phc_code'];
				$user['title']="Drugs Stock Register";
				$dt=$this->input->post('date');



				/*warning*/
			 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			 $user['warning']=$warn;
			 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			 $user['all_warning']=$a_warn;

			 $result=$this->Fetch_model->get_report_medW1($user['phc_code'],$dt);

			// $CresultMale=$this->Fetch_model->get_report_medCountD_N_WMale($user['phc_code'],$dt);
			// $CresultFmale=$this->Fetch_model->get_report_medCountD_N_WFmale($user['phc_code'],$dt);

			 //$CresultOMale=$this->Fetch_model->get_report_medCountD_O_WMale($user['phc_code'],$dt);
			  //$CresultOFmale=$this->Fetch_model->get_report_medCountD_O_WFmale($user['phc_code'],$dt);
				if(isset($result)&&!empty($result)){
						 $i=1;
						foreach ($result as $row) {
							?>
							<tr>
								<td><?php echo $i; ?></td>
								<!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
								<td><?php echo $row['drug_name']; ?></td>
								<td><?php echo $row['op_bal']; ?></td>
								<td><?php echo $row['cl_bal']; ?></td>
								<td><?php echo $row['qty_utilised']; ?></td>
								 <td><?php echo $row['cl_rate']; ?></td>
								  <td><?php echo $row['tcost']; ?></td>
								<!--<td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
								<td><p class="break-word"><?php echo $row['dt']; ?></p></td>
								<td><p class="break-word"><?php echo $row['diag']; ?></p></td>
							<!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
							</tr>
							<?php
								$i++;
									}
									?>
									<tr>
 										<td colspan="8">
 											<table class="examples display table table-striped table-bordered" >
 										<th>Total </th>
	 											<th></th>
												 
												</tr>
 											</table>
 										</td>
 							</tr>
									<?php
								}
							 if($result==0){
								 ?>

										<tr>
										 <td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									 </tr>
										<?php
							 }
							}else{
								redirect('/', 'refresh');
							}
	 }


	//***************************//
	function psy_report_date(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $user['title']="Drugs Stock Register";
			 $dt=$this->input->post('date');

			 /*warning*/
			$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			$user['warning']=$warn;
			$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			$user['all_warning']=$a_warn;

			$result=$this->Fetch_model->get_report_psy($user['phc_code'],$dt);

							$CresultMale=$this->Fetch_model->get_report_psyCountD_NMale($user['phc_code'],$dt);
								$CresultFmale=$this->Fetch_model->get_report_psyCountD_NFmale($user['phc_code'],$dt);

							$CresultOMale=$this->Fetch_model->get_report_psyCountD_OMale($user['phc_code'],$dt);
								$CresultOFmale=$this->Fetch_model->get_report_psyCountD_OFmale($user['phc_code'],$dt);

			 if(isset($result)&&!empty($result)){
						$i=1;
					 foreach ($result as $row) {
						 ?>
						 <tr>
							 <td><?php echo $i; ?></td>
							 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
							 <td><?php echo $row['pat_no']; ?></td>
							 <td><?php echo $row['pat_name']; ?></td>
							 <td><?php echo $row['age']; ?></td>
							 <td><?php echo $row['pat_place']; ?></td>
							 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
						<!--	 <td><p class="break-word"><?php echo $row['visit_type']; ?></p></td>-->
							 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
					<!--		 <td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
						 </tr>
						 <?php
							 $i++;
								 }
								 ?>
								 <tr>
									 	<td colspan="7">
											<table class="examples display table table-striped table-bordered" >
												<tr>
													<th>Daily Statistics</th>
													<th>Male</th>
													<th>Female</th>
													<th>Total</th>
												</tr>
												<tr>
													<th>New Patients</th>
			 										<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
													<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
													<td><?php echo $CresultMale+$CresultFmale; ?></td>
												</tr>
												<tr>
													<th>Old Patients</th>
													<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
														<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
														<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
														<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
												</tr>
												<tr>
													<th>Total</th>
			 										<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php echo $CresultMale+$CresultOMale; ?></td>
													<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
													<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
												</tr>
												<tr>
													<th colspan="4">Doctor Name</th>
												</tr>
											</table>
										</td>
							</tr>
	 						<?php
							 }
							if($result==0){
								?>
									 <tr>
										<td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
									</tr>
									 <?php
							}
						 }else{
							 redirect('/', 'refresh');
						 }
	}

	function psy_report_week(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $user['title']="Drugs Stock Register";
			 $dt=$this->input->post('date');



			 /*warning*/
			$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			$user['warning']=$warn;
			$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			$user['all_warning']=$a_warn;

			$result=$this->Fetch_model->get_report_psyW($user['phc_code'],$dt);
			$CresultMale=$this->Fetch_model->get_report_psyCountD_N_WMale($user['phc_code'],$dt);
			$CresultFmale=$this->Fetch_model->get_report_psyCountD_N_WFmale($user['phc_code'],$dt);

			$CresultOMale=$this->Fetch_model->get_report_psyCountD_O_WMale($user['phc_code'],$dt);
			 $CresultOFmale=$this->Fetch_model->get_report_psyCountD_O_WFmale($user['phc_code'],$dt);
			 if(isset($result)&&!empty($result)){
						$i=1;
					 foreach ($result as $row) {
						 ?>
						 <tr>
							 <td><?php echo $i; ?></td>
							 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
							 <td><?php echo $row['pat_no']; ?></td>
							 <td><?php echo $row['pat_name']; ?></td>
							 <td><?php echo $row['age']; ?></td>
							 <td><?php echo $row['pat_place']; ?></td>
							 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
							 <td><p class="break-word"><?php echo $row['dt']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
						 <!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
						 </tr>
						 <?php
							 $i++;
								 }?>
								 <tr>
 									 <td colspan="8">
 										 <table class="examples display table table-striped table-bordered" >
 											 <tr>
 												 <th>Daily Statistics</th>
 												 <th>Male</th>
 												 <th>Female</th>
 												 <th>Total</th>
 											 </tr>
 											 <tr>
 												 <th>New Patients</th>
 												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 												 <td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
 												 <td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
 												 <td><?php echo $CresultMale+$CresultFmale; ?></td>
 											 </tr>
 											 <tr>
 												 <th>Old Patients</th>
 												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 													 <td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
 													 <td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
 													 <td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
 											 </tr>
 											 <tr>
 												 <th>Total</th>
 												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
 												 <td><?php echo $CresultMale+$CresultOMale; ?></td>
 												 <td><?php echo $CresultFmale+$CresultOFmale; ?></td>
 												 <td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
 											 </tr>
											 <tr>
												<th colspan="4">Doctor Name</th>
											</tr>
 										 </table>
 									 </td>
 						 </tr>
							 <?php
							 }
							if($result==0){
								?>

									 <tr>
										<td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									</tr>
									 <?php
							}
						 }else{
							 redirect('/', 'refresh');
						 }
	}

	function psy_report_month(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $user['title']="Drugs Stock Register";
			 $dt=$this->input->post('date');



			 /*warning*/
			$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
			$user['warning']=$warn;
			$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
			$user['all_warning']=$a_warn;

			$result=$this->Fetch_model->get_report_psyM($user['phc_code'],$dt);
			$CresultMale=$this->Fetch_model->get_report_psyCountD_N_MMale($user['phc_code'],$dt);
			$CresultFmale=$this->Fetch_model->get_report_psyCountD_N_MFmale($user['phc_code'],$dt);

			 $CresultOMale=$this->Fetch_model->get_report_psyCountD_O_MMale($user['phc_code'],$dt);
			 $CresultOFmale=$this->Fetch_model->get_report_psyCountD_O_MFmale($user['phc_code'],$dt);
			 if(isset($result)&&!empty($result)){
						$i=1;
					 foreach ($result as $row) {
						 ?>
						 <tr>
							 <td><?php echo $i; ?></td>
							 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
							 <td><?php echo $row['pat_no']; ?></td>
							 <td><?php echo $row['pat_name']; ?></td>
							 <td><?php echo $row['age']; ?></td>
							 <td><?php echo $row['pat_place']; ?></td>
							 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
							 <td><p class="break-word"><?php echo $row['dt']; ?></p></td>
							 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
						 <!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
						 </tr>
						 <?php
							 $i++;
								 }?>
								 <tr>
									 <td colspan="8">
										 <table class="examples display table table-striped table-bordered" >
											 <tr>
												 <th>Daily Statistics</th>
												 <th>Male</th>
												 <th>Female</th>
												 <th>Total</th>
											 </tr>
											 <tr>
												 <th>New Patients</th>
												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												 <td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
												 <td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
												 <td><?php echo $CresultMale+$CresultFmale; ?></td>
											 </tr>
											 <tr>
												 <th>Old Patients</th>
												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													 <td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
													 <td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
													 <td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
											 </tr>
											 <tr>
												 <th>Total</th>
												 <!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												 <td><?php echo $CresultMale+$CresultOMale; ?></td>
												 <td><?php echo $CresultFmale+$CresultOFmale; ?></td>
												 <td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
											 </tr>
											 <tr>
												 <th colspan="4">Doctor Name</th>
											 </tr>

										 </table>
									 </td>
						 </tr>
							 <?php
							 }
							if($result==0){
								?>

									 <tr>
										<td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
									</tr>
									 <?php
							}
						 }else{
							 redirect('/', 'refresh');
						 }
	}


//***************************//
//***************************//

//***************************//
function dent_report_date(){
	if($this->session->userdata('Login')){
		$this->load->model('Fetch_model');
		 $session=$this->session->userdata('Login');
		 $user['user_id']=$session['id'];
		 $user['email']=$session['email'];
		 $user['name']=$session['name'];
		 $user['role']=$session['role'];
		 $user['phc_code']=$session['phc_code'];
		 $user['title']="Drugs Stock Register";
		 $dt=$this->input->post('date');

		 /*warning*/
		$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		$user['warning']=$warn;
		$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		$user['all_warning']=$a_warn;

		$result=$this->Fetch_model->get_report_dent($user['phc_code'],$dt);
		$CresultMale=$this->Fetch_model->get_report_dentCountD_NMale($user['phc_code'],$dt);
			$CresultFmale=$this->Fetch_model->get_report_dentCountD_NFmale($user['phc_code'],$dt);

		$CresultOMale=$this->Fetch_model->get_report_dentCountD_OMale($user['phc_code'],$dt);
			$CresultOFmale=$this->Fetch_model->get_report_dentCountD_OFmale($user['phc_code'],$dt);
		 if(isset($result)&&!empty($result)){
					$i=1;
				 foreach ($result as $row) {
					 ?>
					 <tr>

						 <td><?php echo $i; ?></td>
						 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
						 <td><?php echo $row['pat_no']; ?></td>
						 <td><?php echo $row['pat_name']; ?></td>
						 <td><?php echo $row['age']; ?></td>
						 <td><?php echo $row['pat_place']; ?></td>
						 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
					<!--	 <td><p class="break-word"><?php echo $row['visit_type']; ?></p></td>-->
						 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
				<!--		 <td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
					 </tr>
					 <?php
						 $i++;
							 }
							 ?>
							 <tr>
									<td colspan="7">
										<table class="examples display table table-striped table-bordered" >
											<tr>
												<th>Daily Statistics</th>
												<th>Male</th>
												<th>Female</th>
												<th>Total</th>
											</tr>
											<tr>
												<th>New Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
												<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
												<td><?php echo $CresultMale+$CresultFmale; ?></td>
											</tr>
											<tr>
												<th>Old Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
													<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
													<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
											</tr>
											<tr>
												<th>Total</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php echo $CresultMale+$CresultOMale; ?></td>
												<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
												<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
											</tr>
											<tr>
												<th colspan="4">Doctor Name</th>
											</tr>
										</table>
									</td>
						</tr>
		 				<?php
						 }
						if($result==0){
							?>
								 <tr>
									<td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
								</tr>
								 <?php
						}
					 }else{
						 redirect('/', 'refresh');
					 }
}

function dent_report_week(){
	if($this->session->userdata('Login')){
		$this->load->model('Fetch_model');
		 $session=$this->session->userdata('Login');
		 $user['user_id']=$session['id'];
		 $user['email']=$session['email'];
		 $user['name']=$session['name'];
		 $user['role']=$session['role'];
		 $user['phc_code']=$session['phc_code'];
		 $user['title']="Drugs Stock Register";
		 $dt=$this->input->post('date');



		 /*warning*/
		$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		$user['warning']=$warn;
		$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		$user['all_warning']=$a_warn;

		$result=$this->Fetch_model->get_report_dentW($user['phc_code'],$dt);
		$CresultMale=$this->Fetch_model->get_report_dentCountD_N_WMale($user['phc_code'],$dt);
		$CresultFmale=$this->Fetch_model->get_report_dentCountD_N_WFmale($user['phc_code'],$dt);

		$CresultOMale=$this->Fetch_model->get_report_dentCountD_O_WMale($user['phc_code'],$dt);
		 $CresultOFmale=$this->Fetch_model->get_report_dentCountD_O_WFmale($user['phc_code'],$dt);
		 if(isset($result)&&!empty($result)){
					$i=1;
				 foreach ($result as $row) {
					 ?>
					 <tr>
						 <td><?php echo $i; ?></td>
						 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
						 <td><?php echo $row['pat_no']; ?></td>
						 <td><?php echo $row['pat_name']; ?></td>
						 <td><?php echo $row['age']; ?></td>
						 <td><?php echo $row['pat_place']; ?></td>
						 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
						 <td><p class="break-word"><?php echo $row['dt']; ?></p></td>
						 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
					 <!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
					 </tr>
					 <?php
						 $i++;
							 }?>
							 <tr>
									<td colspan="8">
										<table class="examples display table table-striped table-bordered" >
											<tr>
												<th>Daily Statistics</th>
												<th>Male</th>
												<th>Female</th>
												<th>Total</th>
											</tr>
											<tr>
												<th>New Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
												<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
												<td><?php echo $CresultMale+$CresultFmale; ?></td>
											</tr>
											<tr>
												<th>Old Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
													<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
													<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
											</tr>
											<tr>
												<th>Total</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php echo $CresultMale+$CresultOMale; ?></td>
												<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
												<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
											</tr>
											<tr>
												<th colspan="4">Doctor Name</th>
											</tr>
										</table>
									</td>
						</tr>
						 <?php
						 }
						if($result==0){
							?>

								 <tr>
									<td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
								</tr>
								 <?php
						}
					 }else{
						 redirect('/', 'refresh');
					 }
}

function dent_report_month(){
	if($this->session->userdata('Login')){
		$this->load->model('Fetch_model');
		 $session=$this->session->userdata('Login');
		 $user['user_id']=$session['id'];
		 $user['email']=$session['email'];
		 $user['name']=$session['name'];
		 $user['role']=$session['role'];
		 $user['phc_code']=$session['phc_code'];
		 $user['title']="Drugs Stock Register";
		 $dt=$this->input->post('date');



		 /*warning*/
		$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		$user['warning']=$warn;
		$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		$user['all_warning']=$a_warn;

		$result=$this->Fetch_model->get_report_dentM($user['phc_code'],$dt);
		$CresultMale=$this->Fetch_model->get_report_dentCountD_N_MMale($user['phc_code'],$dt);
		$CresultFmale=$this->Fetch_model->get_report_dentCountD_N_MFmale($user['phc_code'],$dt);

		 $CresultOMale=$this->Fetch_model->get_report_dentCountD_O_MMale($user['phc_code'],$dt);
		 $CresultOFmale=$this->Fetch_model->get_report_dentCountD_O_MFmale($user['phc_code'],$dt);
		 if(isset($result)&&!empty($result)){
					$i=1;
				 foreach ($result as $row) {
					 ?>
					 <tr>
						 <td><?php echo $i; ?></td>
						 <!--  <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>-->
						 <td><?php echo $row['pat_no']; ?></td>
						 <td><?php echo $row['pat_name']; ?></td>
						 <td><?php echo $row['age']; ?></td>
						 <td><?php echo $row['pat_place']; ?></td>
						 <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
						 <td><p class="break-word"><?php echo $row['dt']; ?></p></td>
						 <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
					 <!--	<td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>-->
					 </tr>
					 <?php
						 $i++;
							 }?>
							 <tr>
									<td colspan="8">
										<table class="examples display table table-striped table-bordered" >
											<tr>
												<th>Daily Statistics</th>
												<th>Male</th>
												<th>Female</th>
												<th>Total</th>
											</tr>
											<tr>
												<th>New Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php  if($CresultMale!= Null){ echo $CresultMale; }else{ echo "0" ;}; ?></td>
												<td><?php  if($CresultFmale != Null){ echo $CresultFmale; }else{ echo "0" ;}; ?></td>
												<td><?php echo $CresultMale+$CresultFmale; ?></td>
											</tr>
											<tr>
												<th>Old Patients</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
													<td><?php  if($CresultOMale != Null){ echo $CresultOMale; }else{ echo "0" ;}; ?></td>
													<td><?php  if($CresultOFmale != Null){ echo $CresultOFmale;}else{ echo "0" ;}; ?></td>
													<td><?php echo $CresultOMale+$CresultOFmale;  ?></td>
											</tr>
											<tr>
												<th>Total</th>
												<!--<td><?php echo $Cresult[0]['total']; ?></td>-->
												<td><?php echo $CresultMale+$CresultOMale; ?></td>
												<td><?php echo $CresultFmale+$CresultOFmale; ?></td>
												<td><?php echo ($CresultMale+$CresultFmale)+($CresultOMale+$CresultOFmale); ?></td>
											</tr>
											<tr>
												<th colspan="4">Doctor Name</th>
											</tr>
										</table>
									</td>
						</tr>
						 <?php
						 }
						if($result==0){
							?>

								 <tr>
									<td colspan="6"><center><span style="color:red"><?php echo "Dears User, No data on this date.."; ?></span></center></td>
								</tr>
								 <?php
						}
					 }else{
						 redirect('/', 'refresh');
					 }
}


//***************************//

	function drug_stocks_by_date(){
		if($this->session->userdata('Login')){
			$this->load->model('Fetch_model');
			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $user['title']="Drugs Stock Register";
			 $dt=$this->input->post('date');

			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;

			 $result=$this->Fetch_model->get_stock_by_date($user['phc_code'],$dt);
			 if(isset($result)&&!empty($result)){

					 foreach ($result as $row) {
						 ?>
						 <tr>
							 <td><?php echo $row['drug_name']; ?></td>
							 <td><?php echo $row['op_bal']; ?></td>
							 <td><?php echo $row['qty_utilised']; ?></td>
							 <td><?php echo $row['qty_requested']; ?></td>
							 <td><?php echo $row['qty_added']; ?></td>
							 <td><?php echo $row['cl_bal']; ?></td>
							</tr>
						 <?php
						}

							 }
							if($result==0){
								?>
 								 <tr>
 									<td colspan="6"><center><span style="color:red"><?php echo "Dear User, No data on this date.."; ?></span></center></td>
 								</tr>
 								 <?php
							}
						 }else{
							 redirect('/', 'refresh');
						 }
 }




 function admin_drug_stocks_by_date(){
  if($this->session->userdata('Login')){
 		 $this->load->model('User_model');
 		 $session=$this->session->userdata('Login');
 		 $user['user_id']=$session['id'];
 		 $user['email']=$session['email'];
 		 $user['name']=$session['name'];
 		 $user['role']=$session['role'];
 		 $user['phc_code']=$session['phc_code'];
 		 $user['title']="Drugs Stock Register";
 		 $result=$this->User_model->get_phc();
 		 $user['phc']=$result;
		 /*warning*/
	 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
	 	$user['warning']=$warn;
	 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
	 	$user['all_warning']=$a_warn;

 		 $dt=$this->input->post('date');
 		 $rhc=$this->input->post('phc');

 		 $result=$this->Fetch_model->admin_get_stock_by_date($rhc,$dt);
 		 $user['stock']=$result;
 		 $this->load->view('new/admin_drugs_stock',$user);

 	 }else{
 						redirect('/', 'refresh');
 					}
 }
/************************/
			function index_email(){
					$usr=trim($this->input->post('email'));
					$result=$this->Add_model->get_email($usr);
					if($result==true)
					{
						echo "Already Exists...!!";
					}
					else{

					}
			 }

			 function search_pat(){
				 if($this->session->userdata('Login')){
					 $this->load->model('Fetch_model');
						$session=$this->session->userdata('Login');
						$user['user_id']=$session['id'];
						$user['email']=$session['email'];
						$user['name']=$session['name'];
						$user['role']=$session['role'];
						$user['phc_code']=$session['phc_code'];
						$usr=$this->input->post('keyword');
					 	$usr=trim($usr);
					 	$rh=$user['phc_code'];
						/*warning*/
						$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
						$user['warning']=$warn;
						$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
						$user['all_warning']=$a_warn;
						$result=$this->Add_model->search_pat($usr,$rh);
					 	if($result)
					 	{
						 ?>
							<ul id="search-list" class="list-group">
								<?php
									foreach ($result as $row) {
								?>
								<li class="list-group-item list-group-item-info" onClick="selectDrug('<?php echo $row['pat_no'];?>');"><?php echo "<label><font color=red>Patient ID</font></label>:&nbsp<font color=black>".$row['pat_no']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>NRK ID</label></font>:&nbsp<font color=black>".$row['nrkid']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>Patient Name</label></font>:&nbsp<font color=black>".$row['pat_name']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>Father Name</label></font>:&nbsp<font color=black>".$row['pat_father']."</font>"; ?>
										&nbsp|| &nbsp<?php echo "<label><font color=red>Address</label></font>:&nbsp<font color=black>".$row['pat_addrs']."</font>"; ?></li>
							 <?php
							 }
							?>
						</ul>
						<?php
					} else{
						?>
						 <ul id="search-list" class="form-control">
							 <li>No Results...</li>
						 </ul>
					 <?php
					 }
				 }else{
					redirect('/', 'refresh');
				 }
				}
				function search_lab_pat(){
					if($this->session->userdata('Login')){
						$this->load->model('Fetch_model');
						 $session=$this->session->userdata('Login');
						 $user['user_id']=$session['id'];
						 $user['email']=$session['email'];
						 $user['name']=$session['name'];
						 $user['role']=$session['role'];
						 $user['phc_code']=$session['phc_code'];
						 $usr=$this->input->post('keyword');
						 $usr=trim($usr);
						 $rh=$user['phc_code'];
						 /*warning*/
						 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
						 $user['warning']=$warn;
						 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
						 $user['all_warning']=$a_warn;

						 $result=$this->Add_model->search_lab_pat($usr,$rh);
						 if($result)
						 {
							?>
							 <ul id="search-list" class="list-group">
								 <?php
									 foreach ($result as $row) {
								 ?>
								 <li class="list-group-item list-group-item-info" onClick="selectDrug('<?php echo $row['ref_id'];?>');"><?php echo "<label><font color=red>Referred ID</font></label>:&nbsp<font color=black>".$row['pat_id']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>OP Patient ID</font></label>:&nbsp<font color=black>".$row['op_file_no']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>NRK ID</label></font>:&nbsp<font color=black>".$row['nrkid']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>Patient Name</label></font>:&nbsp<font color=black>".$row['pat_name']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>Referred Hospital Name</label></font>:&nbsp<font color=black>".$row['phc_name']."</font>"; ?>
										 &nbsp  &nbsp<?php //echo "<label><font color=red>Address</label></font>:&nbsp<font color=black>".$row['pat_addrs']."</font>"; ?></li>
								<?php
								}
							 ?>
						 </ul>
						 <?php
					 } else{
						 ?>
							<ul id="search-list" class="form-control">
								<li>No Results...</li>
							</ul>
						<?php
						}
					}else{
					 redirect('/', 'refresh');
					}
				 }
				 function search_lab_pat_t(){
				 	if($this->session->userdata('Login')){
				 		$this->load->model('Fetch_model');
				 		 $session=$this->session->userdata('Login');
				 		 $user['user_id']=$session['id'];
				 		 $user['email']=$session['email'];
				 		 $user['name']=$session['name'];
				 		 $user['role']=$session['role'];
				 		 $user['phc_code']=$session['phc_code'];
				 		 $usr=$this->input->post('keyword');
				 		 $usr=trim($usr);
				 		 $rh=$user['phc_code'];
				 		 /*warning*/
				 		 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
				 		 $user['warning']=$warn;
				 		 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
				 		 $user['all_warning']=$a_warn;

				 		 $result=$this->Add_model->search_lab_pat_t($usr,$rh);
				 		 if($result)
				 		 {
				 			?>
				 			 <ul id="search-list" class="list-group">
				 				 <?php
				 					 foreach ($result as $row) {
				 				 ?>
				 			 <li class="list-group-item list-group-item-info" onClick="selectDrug('<?php echo $row['pat_id'];?>');"><?php echo "<label><font color=red>Lab Reg ID</font></label>:&nbsp<font color=black>".$row['refer_id']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>OP Patient ID</font></label>:&nbsp<font color=black>".$row['op_no']."</font>"; ?>&nbsp|| &nbsp<?php echo "<label><font color=red>Patient Name</label></font>:&nbsp<font color=black>".$row['pat_name']."</font>"; ?></li>
				 				<?php
				 				}
				 			 ?>
				 		 </ul>
				 		 <?php
				 	 } else{
				 		 ?>
				 			<ul id="search-list" class="form-control">
				 				<li>No Results...</li>
				 			</ul>
				 		<?php
				 		}
				 	}else{
				 	 redirect('/', 'refresh');
				 	}
				  }

					public function grp(){
						if($this->session->userdata('Login')){
								$session=$this->session->userdata('Login');
								$user['user_id']=$session['id'];
								$user['email']=$session['email'];
								$user['name']=$session['name'];
								$user['role']=$session['role'];
								$user['phc_code']=$session['phc_code'];
								$user['title']="Graph";
								 $user['grp']= $this->input->post('p');
								 /*warning*/
								 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
								 $user['warning']=$warn;
								 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
								 $user['all_warning']=$a_warn;
								$this->load->view('new/graph',$user);
						}else{
							redirect('/', 'refresh');
						}
					}
					public function lab_grp(){
						if($this->session->userdata('Login')){
								$session=$this->session->userdata('Login');
								$user['user_id']=$session['id'];
								$user['email']=$session['email'];
								$user['name']=$session['name'];
								$user['role']=$session['role'];
								$user['phc_code']=$session['phc_code'];
								$user['title']="Graph";
								 $user['grp']= $this->input->post('p');
								 $user['grp1']= $this->input->post('p1');
								 /*warning*/
								 $warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
								 $user['warning']=$warn;
								 $a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
								 $user['all_warning']=$a_warn;
								$this->load->view('new/lab_graph',$user);
						}else{
							redirect('/', 'refresh');
						}
					}

					public function update_user(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
						if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('usr_id');
								 $data = array(

										 'name' => $this->input->post('usr_name'),
										 'email' => $this->input->post('email'),
										 'phone' => $this->input->post('phone')

							 );
							 /*warning*/
						 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
						 	$user['warning']=$warn;
						 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
						 	$user['all_warning']=$a_warn;
							 $result=$this->Update_model->update_user($data,$u_id);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Updated Successfully...!!");
								</script><?php
										redirect('Myhome/modify_incharge','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_incharge','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}


					public function delete_user(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
						if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('usr_id');
									$result=$this->Update_model->delete_user($u_id);
									/*warning*/
									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;
									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;
							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Deleted Successfully...!!");
								</script><?php
										redirect('Myhome/modify_incharge','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_incharge','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}

					public function update_phc(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
						if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('phc_id');
								 $data = array(
										'phc_name' => $this->input->post('phc_name'),
										'phc_code' => $this->input->post('phc_code'),
										'phc_phn' => $this->input->post('phc_phn'),
										'phc_addr' => $this->input->post('phc_addr')

							);
							/*warning*/
							$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
							$user['warning']=$warn;
							$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
							$user['all_warning']=$a_warn;

							 $result=$this->Update_model->update_phc($data,$u_id);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Updated Successfully...!!");
								</script><?php
										redirect('Myhome/modify_phc','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_phc','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}

					public function delete_phc(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
						if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('phc_id');
									$result=$this->Update_model->delete_phc($u_id);
									/*warning*/
									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;
									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;
							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Deleted Successfully...!!");
								</script><?php
										redirect('Myhome/modify_phc','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_phc','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}

					public function update_drugs(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
							if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('drug_id');
								 $data = array(

										'drug_name' => $this->input->post('drug_name'),
										'quantity' => $this->input->post('quantity'),
										'measure' => $this->input->post('measure'),
										'expr_date' => $this->input->post('expr_date'),
										'rate' => $this->input->post('rate'),
									);
									/*warning*/
									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;
									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;

							 $result=$this->Update_model->update_drugs($data,$u_id);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Updated Successfully...!!");
								</script><?php
										redirect('Myhome/modify_drugs','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_drugs','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}

					public function delete_drugs(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
							if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('drug_id');
								 $trig_id=$this->input->post('trig');
								 if($trig_id==1){
									 $data = array(

										 'trig' =>0

									 );
								 }else{
									 $data = array(

										 'trig' =>1

									 );
								 }

								 /*warning*/
							 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
							 	$user['warning']=$warn;
							 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
							 	$user['all_warning']=$a_warn;
							 $result=$this->Update_model->delete_drugs($u_id,$data);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert(" Success...!!");
								</script><?php
										redirect('Myhome/modify_drugs','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_drugs','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}

					public function delete_tests(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
							if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('test_id');
								 $trig_id=$this->input->post('status');
								 if($trig_id==1){
									 $data = array(

										 'status' =>0

									 );
								 }else{
									 $data = array(

										 'status' =>1

									 );
								 }

								 /*warning*/
								$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
								$user['warning']=$warn;
								$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
								$user['all_warning']=$a_warn;
							 $result=$this->Update_model->delete_tests($u_id,$data);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert(" Success...!!");
								</script><?php
										redirect('Myhome/modify_lab_comp','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_lab_comp','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}


					public function update_tests(){
						if(isset($_POST['submit']) && !empty($_POST['submit'])){

							$this->load->model('Update_model');
							if($this->session->userdata('Login')){
								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $u_id=$this->input->post('drug_id');
								 $data = array(

										'test_name' => $this->input->post('drug_name'),
										'test_range' => $this->input->post('test_range'),

									);
									/*warning*/
									$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
									$user['warning']=$warn;
									$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
									$user['all_warning']=$a_warn;

							 $result=$this->Update_model->update_tests($data,$u_id);

							 if($result==1){?>
								 <script type="text/javascript">
												 alert("Updated Successfully...!!");
								</script><?php
										redirect('Myhome/modify_lab_comp','refresh');
							 }else{?>
								 <script type="text/javascript">
												 alert("Failed...!!!");
								</script><?php
								redirect('Myhome/modify_lab_comp','refresh');
							 }

						 }else{
							 redirect('/', 'refresh');
						 }
					 }
					}












					public function admin_confirm_drug(){

						if(isset($_POST['submit']) && !empty($_POST['submit'])){

						if($this->session->userdata('Login')){

								 $session=$this->session->userdata('Login');
								 $user['user_id']=$session['id'];
								 $user['email']=$session['email'];
								 $user['name']=$session['name'];
								 $user['role']=$session['role'];
								 $user['phc_code']=$session['phc_code'];
								 $drug_id = $this->input->post('drug_id');
					 		   $cur_quantity= $this->input->post('cur_quantity');
								 $req_quantity = $this->input->post('rec_quantity');
								 $month = $this->input->post('month');
								 $hist_id = $this->input->post('hist_id');
								 $phc=$this->input->post('rhc_id');

								 /*warning*/
							 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
							 	$user['warning']=$warn;
							 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
							 	$user['all_warning']=$a_warn;
									for($i=0;$i<count($drug_id);$i++)
											{
												$data = array('drug_id' =>$drug_id[$i],'phc_code'=>$phc[$i],'cur_quantity' => $cur_quantity[$i],'rec_quantity'=>$req_quantity[$i],'month_year'=>$month[$i],'status' =>2);
												$result=$this->Add_model->admin_confirm($data,$hist_id[$i],$phc[$i]);
												$admin=$this->Add_model->get_incharge_email($phc[$i]);
											}
											if($result==1){

												foreach ($admin as $ad) {
												 $this->load->library('My_PHPMailer');
												 $mail = new PHPMailer();
												 $mail->IsSMTP(); // we are going to use SMTP
												 $mail->SMTPAuth   = true; // enabled SMTP authentication
												 $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
												 $mail->Host       = "smtp.gmail.com";      // setting GMail as our SMTP server
												 $mail->Port       = 465;                   // SMTP port to connect to GMail
												 $mail->Username   = "phc.noreply@gmail.com";  // user email address
												 $mail->Password   = "27punithsr";            // password in GMail
												 $mail->SetFrom("phc.noreply@gmail.com","Admin");  //Who is sending the email
												 $mail->AddReplyTo($user['email'],$user['name']);  //email address that receives the response
												 $mail->Subject    = "Drug request is Approved";
												 $mail->Body      = "HTMLfrg message";
												 $mail->AltBody    = "Plain text message";
												 $reciver = $ad['email']; // Who is addressed the email to
												 $mail->AddAddress($reciver, $ad['name']);

												 $mail->AddAttachment("images/phpmailer.gif");      // some attached files
												 $mail->AddAttachment("images/phpmailer_mini.gif"); // as many as you want
												 $mail->Send();
											 }?>
												 <script type="text/javascript">
																 alert("Request Accepted Successfully...!!");
												</script><?php
														redirect('Myhome/admin_req_indent','refresh');
											 }else{?>
												 <script type="text/javascript">
																 alert("Request Accept Failed..");
												</script><?php
														redirect('Myhome/admin_req_indent','refresh');
											 }
					 				 }else{
							 redirect('/', 'refresh');
						 }

					}
}


public function add_rec_drug(){

	if(isset($_POST['submit']) && !empty($_POST['submit'])){

	if($this->session->userdata('Login')){

			 $session=$this->session->userdata('Login');
			 $user['user_id']=$session['id'];
			 $user['email']=$session['email'];
			 $user['name']=$session['name'];
			 $user['role']=$session['role'];
			 $user['phc_code']=$session['phc_code'];
			 $drug_id = $this->input->post('drug_id');
			 $hist_id = $this->input->post('hist_id');
			 $req_quantity = $this->input->post('rec_quantity');
			 /*warning*/
		 	$warn=$this->Fetch_model->get_drug_warning($user['phc_code']);
		 	$user['warning']=$warn;
		 	$a_warn=$this->Fetch_model->get_all_drug_warning($user['phc_code']);
		 	$user['all_warning']=$a_warn;

			 $phc=$user['phc_code'];


				for($i=0;$i<count($drug_id);$i++)
						{

							$result=$this->Add_model->add_rec_stock($drug_id[$i],$req_quantity[$i],$user['phc_code']);
							$up=$this->Add_model->ack_rec_stock($hist_id[$i]);
						}
						if($result==1){
							$admin=$this->Add_model->get_admin_email();
							foreach ($admin as $ad) {
							 $this->load->library('My_PHPMailer');
							 $mail = new PHPMailer();
							 $mail->IsSMTP(); // we are going to use SMTP
							 $mail->SMTPAuth   = true; // enabled SMTP authentication
							 $mail->SMTPSecure = "ssl";  // prefix for secure protocol to connect to the server
							 $mail->Host       = "smtp.gmail.com";      // setting GMail as our SMTP server
							 $mail->Port       = 465;                   // SMTP port to connect to GMail
							 $mail->Username   = "phc.noreply@gmail.com";  // user email address
							 $mail->Password   = "27punithsr";            // password in GMail
							 $mail->SetFrom("phc.noreply@gmail.com","Admin");  //Who is sending the email
							 $mail->AddReplyTo($user['email'],$user['name']);   //email address that receives the response
							 $mail->Subject    = "Ack Drugs delivered safely";
							 $mail->Body      = "HTMLack message";
							 $mail->AltBody    = "Plain text message";
							 $reciver = $ad['email']; // Who is addressed the email to
							 $mail->AddAddress($reciver, $ad['name']);

							 $mail->AddAttachment("images/phpmailer.gif");      // some attached files
							 $mail->AddAttachment("images/phpmailer_mini.gif"); // as many as you want
							 $mail->Send();
						 }?>
							 <script type="text/javascript">
											 alert("Ack Sent Successfully...!!");
							</script><?php
									redirect('Myhome/d_req_status','refresh');
						 }else{?>
							 <script type="text/javascript">
											 alert("Ack Sending Failed..");
							</script><?php
									redirect('Myhome/d_req_status','refresh');
						 }
					 }else{
		 redirect('/', 'refresh');
	 }

}
}

}

?>
