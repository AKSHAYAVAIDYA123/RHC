<?php echo $email; 

?>
