<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            KSHM Health Center, Bailur
            <small>Add/Edit/Delete Drugs</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="box box-primary">
              <div class="box-body">
                <div class="row">
                  <div class="col-md-4">
                <button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#myModal">Add New Drug</button>

                  <!-- Modal -->
                  <div class="modal fade" id="myModal" role="dialog">
                    <div class="modal-dialog modal-lg">

                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Add Drugs</h4>
                        </div>
                        <div class="modal-body" style="background:#21D380">
                           <form action="<?php echo base_url(); ?>index.php/Add_details/add_drug" method="post" name="upload_excel" enctype="multipart/form-data">
                            <div class="box-body">
                               <!--  <div class="box-footer">
                                     <input type="button" id="bt"  onclick="add_row();" value="ADD ROW" id="add" class="btn btn-primary">
                                     <input  type="submit" id="bt1" value="submit" name="submit"  class="btn btn-danger ">
                                 </div>-->
                                 <div class="form-group">
                                   <label>PHC Name</label>
                                   <select class="form-control" id="phc_code" name="phc_code" required="">
                                   <?php foreach($phc as $each){ ?>
                                        <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>';
                                    <?php } ?>
                                   </select>
                                 </div>

                                   <div class="col-md-12">
                                     <table id="drugs_table" lass="table table-striped table-bordered" cellspacing="0" width="100%" >
                                    <tr id="row1">

                                       <td><label>Drug Name</label>
                                         <div class="form-group">

                                           <span style='color:red;' id='code_status'></span>
                                           <input type="text" id="id" class="drug_name form-control" name="drug_name[]" placeholder="Enter Drug Name" required="" onkeyup="check_drug();">
                                         </div>
                                       </td>
                                       <td>
                                       </td>
                                       <td>  <label>Quantity</label>
                                         <div class="form-group">

                                           <input type="number"  class="form-control"  max="5000" id="id1"  name="qunt[]" placeholder="Quantity" required="">
                                         </div>
                                       </td>
                                       <td> <label>Measure</label>
                                         <div class="form-group">
                                           <input type="text"  class="form-control"   id="id3"  name="msr[]" placeholder="Measure" required="">
                                         </div>
                                       </td>
                                       <td>  <label>Exp Date</label>
                                         <div class="form-group">

                                           <input type="text"  class="date_pic form-control"  id="id2"  name="exp[]" placeholder="Exp Date" required="">
                                         </div>
                                       </td>

                                        <td>  <label>Rate</label>
                                         <div class="form-group">

                                           <input type="number"  class="form-control"  max="5000" id="id7"  name="rate[]" placeholder="Rate" required="">
                                         </div>
                                       </td>


                                       <td>
                                         <div class="col-md-12">
                                           <button type="button" style="border-radius:15px" class=" btn btn-warning btn-xs" type="button"   onclick="add_row();"  >
                                                 <span class="glyphicon glyphicon-plus"></span>
                                           </button>
                                         </div>
                                       </td>
                                       <td>
                                         <div class="col-md-12">
                                           <span >
                                             <input  type="submit" id="bt1" value="Submit" name="submit"  class="btn btn-danger btn-md ">
                                           </span>
                                         </div>
                                       </td>
                                     </tr>
                                   </table>
                                   </div>
                                 </div><!-- /.box-body -->
                               </form>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                      </div>

                    </div>
                  </div>
                </div>
                <div class="col-md-4">
                  <!-- Trigger the modal with a button -->
                  <button type="button" class="btn btn-info btn-md" data-toggle="modal" data-target="#myModalq">Upload CSV</button>

                  <!-- Modal -->
                  <div id="myModalq" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                      <!-- Modal content-->
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                          <h4 class="modal-title">Upload CSV File</h4>
                        </div>

                        <form action="<?php echo base_url(); ?>index.php/Uploadcsv/import" method="post" name="upload_excel" enctype="multipart/form-data">
                          <div class="modal-body">
                          <center>  <input type="file" name="file" id="file"> </center>
                            <br/><br/>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                            <button class="btn btn-danger btn-md " type="submit" id="submit" name="import">Uplaod</button>
                          </div>

                          </form>


                      </div>

                    </div>
                  </div>

                </div>
                  <div class="col-md-4">
                    <div class="form-group ">

                        <select  id="phc" >
                          <option value="0">Select PHC</option>
                            <?php foreach($phc as $each){ ?>
                                 <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>
                             <?php } ?>
                          </select>


                      </div>
                  </div>

                </div>


                    <table id="xexample1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                      <thead>
                          <tr>
                            <th>Drug Name</th>
                            <th>Quantity</th>
                            <th>Exp. Date</th>
                            <th>Rate</th>
                            <th>Edit</th>
                            <th>Delete</th>
                          </tr>
                      </thead>

                      <tbody id="code">

                      </tbody>


                    </table>

                  </div><!-- /.box-body -->
                </div><!-- /.box -->
          </div>
        </section><!-- /.content -->
      </div><!-- /.content-wrapper
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2017 .</strong> All rights reserved.
      </footer>-->

      </div><!-- ./wrapper -->

      <!-- jQuery 2.1.4 -->

      <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
      <!-- jQuery UI 1.11.4 -->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />-->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css" />

      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
      <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
      <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

      <script type="text/javascript">

      $(document).ready(function(){
          $('#id').bind("cut copy paste",function(e) {
            e.preventDefault();
            alert("Cut or Copy or Paste is not allowed..!!!");
          });
        });
        $( function() {
           $( ".date_pic" ).datepicker({
             setDate: new Date(),
             changeMonth: true,
             changeYear: true,
               format:'yyyy-mm-dd'
           });
         } );
      /**********************/
      $('#phc').on('change', function() {
          var a=this.value;

        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Fetch/get_drugs');?>",
        data: {
         i:a,
        },
        success: function (response) {
         $( '#code' ).html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });

      });
      function check_phc(val)
      {
       var name=val;

       if(name)
       {
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Add_details/index1');?>",
        data: {
         phc_id:name,
        },
        success: function (response) {
         $( '.code_status' ).html(response);
           if(response=="OK")
           {
            return true;
           }
           else
           {
            return false;
           }
          }
        });
       }
      }
      function add_row()
       {
          $rowno=$("#drugs_table tr").length;
          $rowno=$rowno+1;
           $a = $('#id').val();
          $b = $('#id1').val();
          $e = $('#id2').val();
          $m = $('#id3').val();
          $c = $('#di1').val();
          $d = $('#di2').val();
           $g = $('#id7').val();
          if(($a!="") && ($b!="")){
            $("#drugs_table tr:last").after('<tr id="row'+$rowno+'"><td><div class="form-group"><input type="text" class="form-control" value="'+ $a +'"  name="drug_name[]" placeholder="Enter Drug Name"  readonly></div></td><td>  &nbsp<input type="text" id="di1" value="'+$c+'" hidden name="drug_id[]" ><input type="number" id="di2" value="'+$d+'" name="drug_qty[]" hidden=""></td><td><div class="form-group"><input type="text" value="'+$b+'" name="qunt[]" class="form-control" placeholder="Enter Quantity" readonly></div></td><td><div class="form-group"><input type="text" value="'+$m+'" name="msr[]" class="form-control" placeholder="Enter Measure" readonly></div></td><td><div class="form-group"><input type="text" value="'+$e+'" name="exp[]" class="form-control" placeholder="Enter Exp Date" readonly></div></td><td><div class="form-group"><input type="text" value="'+$g+'" name="rate[]" class="form-control" placeholder="Enter Exp Date" readonly></div></td><td><div class="form-group"><img src="<?php echo base_url();?>img/no.png" id="delete"  onclick="delete_row('+$rowno+')"></div></td></tr>');
            $("#id").css("border","2px solid black");
            $("#id1").css("border","2px solid black ");
            $a = $('#id').val("");
            $b = $('#id1').val("");
            $c = $('#id1').val("");
            $e = $('#id2').val("");
            $m = $('#id3').val("");
             $g = $('#id7').val("");
          }else if(($a=="") && ($b="")){
            $("#id").css("border","3px solid red");
            $("#id1").css("border","3px solid red");
          }else if($a==""){
            $("#id").css("border","3px solid red");
          }else if($b==""){
            $("#id1").css("border","3px solid red");
          }
       }

       function delete_row(rowno)
       {

        $("#row"+rowno).remove();
      }

      function check_drug()
      {
       var name=document.querySelector('.drug_name').value;
        var phc=document.getElementById('phc_code').value;

       if(name)
       {
        $.ajax({
        type: 'post',
        url: "<?php echo site_url('Add_details/index3');?>",
        data: {
         drug_name:name,
         phc_code:phc
        },
        success: function (response) {
         $( '#code_status' ).html(response);
           if(response=="OK")
           {

            return true;
           }
           else
           {

            return false;
           }
          }
        });
       }
      }
/***********/
$(document).ready(function (){
  $.ajax({
  type: 'post',
  url: "<?php echo site_url('Fetch/notification');?>",

  success: function (response) {
    $( '#notification_count').html(response);
     if(response=="OK")
     {
      return true;
     }
     else
     {
      return false;
     }
    }
  });

});

$(document).ready(function (){
   var phc = $('#21').val();

  $.ajax({
  type: 'post',
  url: "<?php echo site_url('Fetch/notification1');?>",
  data:{
    p:phc,
  },
  success: function (response) {
    $( '#notification_count1').html(response);
     if(response=="OK")
     {
      return true;
     }
     else
     {
      return false;
     }
    }
  });

});


      </script>

      <!-- Bootstrap 3.3.5-->
      <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
      <!-- Morris.js charts -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <!--  <script src="<?php echo base_url();?>plugins/morris/morris.min.js"></script>-->
      <!-- Sparkline -->
      <script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
      <!-- jvectormap -->
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <!-- jQuery Knob Chart -->
      <script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
      <!-- daterangepicker -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
      <script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
      <!-- datepicker -->
      <script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <!-- Slimscroll -->
      <script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url();?>plugins/fastclick/fastclick.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo base_url();?>dist/js/app.min.js"></script>
      <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!--    <script src="<?php echo base_url();?>dist/js/pages/dashboard.js"></script>-->
      <!-- AdminLTE for demo purposes -->
      <script src="<?php echo base_url();?>dist/js/demo.js"></script>
      <style>

   #myModal  .modal-dialog {
      width: 100%;
      height: 100%;
      margin: 0;
      padding: 0;
    }

  #myModal   .modal-content {
      height: auto;
      min-height: 100%;
      border-radius: 0;
    }
      </style>

  </body>

</html>
