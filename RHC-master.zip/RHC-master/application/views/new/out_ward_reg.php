<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Drugs Outward Register
            <small>Medicine Outward Details</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="box box-primary">


              <!-- form start -->
              <div class="box-body">

                <center><table border="0" cellspacing="5" cellpadding="5">
                  <tbody><tr>
                      <td><b>Minimum age:</b></td>
                      <td><input type="text" id="min" name="min"  class="form-control"></td>

                      <td>&nbsp <b>Maximum age:</b></td>
                      <td><input type="text" id="max" name="max" class="form-control"></td>
                  </tr>
                </tbody>
              </table> </center>
                <table id="example" class="display table table-striped table-bordered" cellspacing="0" width="100%">
                  <thead>
                    <tr>
                        <th>SI No</th>
                        <th>Date</th>
                        <th>Patient ID</th>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Sex</th>
                        <th>Treatment Type</th>
                        <th>Complaints</th>
                        <th>Findings</th>
                        <th>Diagonosis</th>
                        <th>Investigation</th>
                        <th>Treatment</th>
                        <th>Reference</th>
                        <th>Prescription</th>
                      </tr>

                  </thead>
            <!--  <tfoot>
                      <tr>
                        <th>SI No</th>
                        <th>Date</th>
                        <th>Patient ID</th>
                        <th>Patient Name</th>
                        <th>Age</th>
                        <th>Sex</th>
                        <th>Complaints</th>

                        <th>Findings</th>
                        <th>Diagonosis</th>
                        <th>Investigation</th>
                        <th>Treatment</th>
                        <th>Reference</th>
                        <th>Prescription</th>


                      </tr>
                  </tfoot>-->
                  <tbody>

                    <?php
                      $i=1;
                        if(isset($stock)&&!empty($stock)){
                        foreach ($stock as $row) {
                      ?>
                        <tr>
                          <td><?php echo $i; ?></td>

                          <td><?php echo  date("d-M-Y",strtotime($row['dt'])); ?></td>
                          <td><?php echo $row['pat_no']; ?></td>
                          <td><?php echo $row['pat_name']; ?></td>
                          <td><?php echo $row['age']; ?></td>
                          <td><?php if($row['sex']==1){print_r('Male'); }else{ print_r('Female');}  ?></td>
                          <td><p class="break-word"><?php echo $row['visit_type']; ?></p></td>
                          <td><p class="break-word"><?php echo $row['compl']; ?></p></td>
                          <td><p class="break-word"><?php echo $row['find']; ?></p></td>
                          <td><p class="break-word"><?php echo $row['diag']; ?></p></td>
                          <td><p class="break-word"><?php echo $row['invest']; ?></p></td>
                          <td><p class="break-word"><?php echo $row['treat']; ?></p></td>
                          <td><p class="break-word">
                            <?php foreach($ref_phc as $each){ ?>
                                 <?php  if($row['ref']== $each->phc_code){ echo $each->phc_name;} ?>
                             <?php } ?>
                            </p></td>
                          <td><p class="break-word"><?php echo str_replace(',', ',<br />', $row['drug']); ?></p></td>
                        </tr>
                    <?php
                    $i++;
                      }
                    }?>
                  </tbody>
                </table>
                <style>
                .break-word {
                width: 20em;
              /*  background: lime;*/
              color:black;

                overflow-wrap: break-word;
              }
              .break-word:hover{
                font-size: 20px;
                color:red;

              }

                </style>
              </div><!-- /.box-body -->
          <!--  <div class="box-footer">
                    <input type="submit" value="submit" name="submit"  class="btn btn-primary">
            </div>-->

            </div><!-- /.box -->
          </div>
      </section><!-- /.content -->
      </div><!-- /.content-wrapper
      <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 2.3.0
        </div>
        <strong>Copyright &copy; 2017 .</strong> All rights reserved.
      </footer>-->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->

      </div><!-- ./wrapper -->

      <!-- jQuery 2.1.4 -->

      <script src="<?php echo base_url();?>plugins/jQuery/jQuery-2.1.4.min.js"></script>
      <!-- jQuery UI 1.11.4 -->
      <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
       <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
       <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css" />-->
       <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" />
       <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.3.1/css/buttons.dataTables.min.css" />

      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script>
      <script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.print.min.js"></script>
      <script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
      <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->

      <script type="text/javascript">



      $( function() {
         $( "#dat1" ).datepicker({
           setDate: new Date(),
           changeMonth: true,
           changeYear: true,
             format:'yyyy-mm-dd'
         });
       } );

      /*----------------*/
      /* Custom filtering function which will search data in column four between two values */
  $.fn.dataTable.ext.search.push(
      function( settings, data, dataIndex ) {
          var min = parseInt( $('#min').val(), 10 );
          var max = parseInt( $('#max').val(), 10 );
          var age = parseFloat( data[4] ) || 0; // use data for the age column

          if ( ( isNaN( min ) && isNaN( max ) ) ||
               ( isNaN( min ) && age <= max ) ||
               ( min <= age   && isNaN( max ) ) ||
               ( min <= age   && age <= max ) )
          {
              return true;
          }
          return false;
      }
  );

  $(document).ready(function() {
      var table = $('#example').DataTable({
      "dom": 'li<"toolbar">frtBp',
       "scrollX": true,
      });

      // Event listener to the two range filtering inputs to redraw on input
      $('#min, #max').keyup( function() {
          table.draw();
      } );
  /*pick date start
  $("div.toolbar").html('<input id="date_range" type="text" class="col-md-3" placeholder="Pick Date">');
      //END of the data table

      // Date range script - Start of the sscript
      $("#date_range").daterangepicker({
       autoUpdateInput: false,
       locale: {
         "cancelLabel": "Clear",
              }
      });

      $("#date_range").on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
         table.draw();
      });

      $("#date_range").on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
         table.draw();
      });
      // Date range script - END of the script

      $.fn.dataTableExt.afnFiltering.push(
      function( oSettings, aData, iDataIndex ) {

       var grab_daterange = $("#date_range").val();
       var give_results_daterange = grab_daterange.split(" to ");
          var filterstart = give_results_daterange[0];
          var filterend = give_results_daterange[1];
          var iStartDateCol = 0; //using column 2 in this instance
          var iEndDateCol = 0;
          var tabledatestart = aData[iStartDateCol];
          var tabledateend= aData[iEndDateCol];

          if ( !filterstart && !filterend )
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && filterend === "")
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isAfter(tabledatestart)) && filterstart === "")
          {
              return true;
          }
          else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && (moment(filterend).isSame(tabledateend) || moment(filterend).isAfter(tabledateend)))
          {
              return true;
          }
          return false;
      }
    );
pick-date close
    */
  } );
        /*----------------*/
        $(document).ready(function (){
          $.ajax({
          type: 'post',
          url: "<?php echo site_url('Fetch/notification');?>",

          success: function (response) {
            $( '#notification_count').html(response);
             if(response=="OK")
             {
              return true;
             }
             else
             {
              return false;
             }
            }
          });

        });

        $(document).ready(function (){
           var phc = $('#21').val();

          $.ajax({
          type: 'post',
          url: "<?php echo site_url('Fetch/notification1');?>",
          data:{
            p:phc,
          },
          success: function (response) {
            $( '#notification_count1').html(response);
             if(response=="OK")
             {
              return true;
             }
             else
             {
              return false;
             }
            }
          });

        });


/*-----old datatable code --------*/
/*----------------*/
/* Custom filtering function which will search data in column four between two values */
/* $.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        var min = parseInt( $('#min').val(), 10 );
        var max = parseInt( $('#max').val(), 10 );
        var age = parseFloat( data[3] ) || 0; // use data for the age column

        if ( ( isNaN( min ) && isNaN( max ) ) ||
             ( isNaN( min ) && age <= max ) ||
             ( min <= age   && isNaN( max ) ) ||
             ( min <= age   && age <= max ) )
        {
            return true;
        }
        return false;
    }
);
$(document).ready( function () {
  var table = $('#example').DataTable({
$('#min, #max').keyup( function() {
 table.draw();
} );
});
});*/
  //Start of the data table
/*   $(document).ready( function () {
   var table = $('#example').DataTable({

     initComplete: function () {
         this.api().columns().every( function () {
             var column = this;
             var select = $('<select><option value="">Select</option></select>')
                 .appendTo( $(column.footer()).empty() )
                 .on( 'change', function () {
                     var val = $.fn.dataTable.util.escapeRegex(
                         $(this).val()
                     );

                     column
                         .search( val ? '^'+val+'$' : '', true, false )
                         .draw();
                 } );

             column.data().unique().sort().each( function ( d, j ) {
                 select.append( '<option value="'+d+'">'+d+'</option>' )
             } );
         } );
     },
     "dom": 'li<"toolbar">frtBp',
      "scrollX": true,


   });

 $("div.toolbar").html('<input id="date_range" type="text" class="col-md-3" placeholder="Pick Date">');
 //END of the data table

 // Date range script - Start of the sscript
 $("#date_range").daterangepicker({
  autoUpdateInput: false,
  locale: {
    "cancelLabel": "Clear",
         }
 });

 $("#date_range").on('apply.daterangepicker', function(ev, picker) {
       $(this).val(picker.startDate.format('YYYY-MM-DD') + ' to ' + picker.endDate.format('YYYY-MM-DD'));
    table.draw();
 });

 $("#date_range").on('cancel.daterangepicker', function(ev, picker) {
       $(this).val('');
    table.draw();
 });
 // Date range script - END of the script

 $.fn.dataTableExt.afnFiltering.push(
 function( oSettings, aData, iDataIndex ) {

  var grab_daterange = $("#date_range").val();
  var give_results_daterange = grab_daterange.split(" to ");
     var filterstart = give_results_daterange[0];
     var filterend = give_results_daterange[1];
     var iStartDateCol = 0; //using column 2 in this instance
     var iEndDateCol = 0;
     var tabledatestart = aData[iStartDateCol];
     var tabledateend= aData[iEndDateCol];

     if ( !filterstart && !filterend )
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && filterend === "")
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isAfter(tabledatestart)) && filterstart === "")
     {
         return true;
     }
     else if ((moment(filterstart).isSame(tabledatestart) || moment(filterstart).isBefore(tabledatestart)) && (moment(filterend).isSame(tabledateend) || moment(filterend).isAfter(tabledateend)))
     {
         return true;
     }
     return false;
 }
 );

 //End of the datable
});*/





      </script>

      <!-- Bootstrap 3.3.5-->
      <script src="<?php echo base_url();?>bootstrap/js/bootstrap.min.js"></script>
      <!-- Morris.js charts -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
      <!--  <script src="<?php echo base_url();?>plugins/morris/morris.min.js"></script>-->
      <!-- Sparkline -->
      <script src="<?php echo base_url();?>plugins/sparkline/jquery.sparkline.min.js"></script>
      <!-- jvectormap -->
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
      <script src="<?php echo base_url();?>plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
      <!-- jQuery Knob Chart -->
      <script src="<?php echo base_url();?>plugins/knob/jquery.knob.js"></script>
      <!-- daterangepicker -->
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
      <script src="<?php echo base_url();?>plugins/daterangepicker/daterangepicker.js"></script>
      <!-- datepicker -->
      <script src="<?php echo base_url();?>plugins/datepicker/bootstrap-datepicker.js"></script>
      <!-- Bootstrap WYSIHTML5 -->
      <script src="<?php echo base_url();?>plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
      <!-- Slimscroll -->
      <script src="<?php echo base_url();?>plugins/slimScroll/jquery.slimscroll.min.js"></script>
      <!-- FastClick -->
      <script src="<?php echo base_url();?>plugins/fastclick/fastclick.min.js"></script>
      <!-- AdminLTE App -->
      <script src="<?php echo base_url();?>dist/js/app.min.js"></script>
      <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <!--  <script src="<?php echo base_url();?>dist/js/pages/dashboard.js"></script>-->
      <!-- AdminLTE for demo purposes -->
      <script src="<?php echo base_url();?>dist/js/demo.js"></script>


  </body>

</html>
