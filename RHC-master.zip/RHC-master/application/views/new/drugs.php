<!DOCTYPE html>
<html>


          <?php
              require('side_menu.html');
          ?>
        </section>
        <!-- /.sidebar -->
      </aside>

      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <h1>
            Primary Health Center (PHC)
            <small>Add Drugs Details</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Dashboard</li>
          </ol>
        </section>

        <!-- Main content -->
        <section class="content">
          <!-- Small boxes (Stat box) -->
          <div class="row">
              <div class="box box-primary">
                <div class="row">

                  <center><h2> Upload CSV File</h2>  </center>

                    <div class="form-group">
                    <center>
                      <form action="<?php echo base_url(); ?>index.php/Uploadcsv/import" method="post" name="upload_excel" enctype="multipart/form-data">
                        <input type="file" name="file" id="file">
                        <br/><br/>
                        <button class="btn btn-danger btn-md " type="submit" id="submit" name="import">Uplaod</button>
                      </form>
                    </center>
                  </div>
                  </div>

                </div>
                <center><h2>OR</h2></center>
                <div class="row">
                <div class="col-md-3" >
                </div>

              <!-- form start -->
              <?php
              echo form_open('Add_details/add_drug'); ?>
                <div class="col-md-6" style="background:#21D380">
                <div class="box-body">
                <!--  <div class="box-footer">
                      <input type="button" id="bt"  onclick="add_row();" value="ADD ROW" id="add" class="btn btn-primary">
                      <input  type="submit" id="bt1" value="submit" name="submit"  class="btn btn-danger ">
                  </div>-->
                  <div class="form-group">
                    <label>PHC Name</label>
                    <select class="form-control" id="phc_code" name="phc_code" required="">
                    <?php foreach($phc as $each){ ?>
                         <option value="<?php echo $each->phc_code; ?>"><?php echo $each->phc_name; ?></option>';
                     <?php } ?>
                    </select>
                  </div>

                    <div class="col-md-12">
                      <table id="drugs_table" lass="table table-striped table-bordered" cellspacing="0" width="100%" >
                     <tr id="row1">

                        <td><label>Drug Name</label>
                          <div class="form-group">

                            <span style='color:red;' id='code_status'></span>
                            <input type="text" id="id" class="drug_name form-control" name="drug_name[]" placeholder="Enter Drug Name" required="" onkeyup="check_drug();">
                          </div>
                        </td>
                        <td>
                        </td>
                        <td>  <label>Quantity</label>
                          <div class="form-group">

                            <input type="number"  class="form-control"  max="5000" id="id1"  name="qunt[]" placeholder="Quantity" required="">
                          </div>
                        </td>
                        <td>
                          <div class="col-md-12">
                            <button type="button" style="border-radius:15px" class=" btn btn-warning btn-xs" type="button"   onclick="add_row();"  >
                                  <span class="glyphicon glyphicon-plus"></span>
                            </button>
                          </div>
                        </td>
                        <td>
                          <div class="col-md-12">
                            <span >
                              <input  type="submit" id="bt1" value="Submit" name="submit"  class="btn btn-danger btn-md ">
                            </span>
                          </div>
                        </td>
                      </tr>
                    </table>
                    </div>

                  </div><!-- /.box-body -->
                </div>
                <?php  form_close(); ?>
                <div class="col-md-3">
                </div>
              </div>
            </div><!-- /.box -->

        </section><!-- /.content -->
      </div><!-- /.content-wrapper -->
  <?php require('footer.html');?>
  <script>
/*  function myFunction(){
    var a = parseInt(document.getElementById("ph").value);
    if(isNaN(a)){
      document.getElementById("ph").style.border="3px solid red";
    }else {
      document.getElementById("ph").style.border="3px solid green";
    }
  }*/
  </script>
  <style>


</style>
</body>
</html>
