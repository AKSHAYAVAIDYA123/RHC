<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Add_model extends CI_Model
{
	function __construct()
    {
        parent::__construct();

    }


	function add_phcd($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('phc',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }

  function add_phcdoc($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('doctor',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }

	function add_user($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('users',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }

	function add_drugs($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('all_drugs',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }
	function add_tests($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('tests',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }

	function req_form($data)
	{

      $this->db->trans_start();
		  $sql= $this->db->insert('drugs_history',$data);
      $this->db->trans_complete();
      if($sql){
        return 1;
      }else{
        return 0;
      }
  }
	function update_test_res($data,$id)
	{

			$res=$this->db->query("update lab_patient_record set test_result='$data' where lab_pat_id='$id'");
			if($res)
			{
						 return 1;
			} else
					 {
						 return 0;
					 }
	}

	function req_confirm($data,$id,$phc)
	{

				$this->db->where('hist_id',$id);
			if( $this->db->update('drugs_history',$data))
			{
						 return 1;
			}
					 else
					 {
						 return 0;
					 }
  }
	function admin_confirm($data,$id,$phc)
	{

				$this->db->where('hist_id',$id);
			if( $this->db->update('drugs_history',$data))
			{
						 return 1;
			}
					 else
					 {
						 return 0;
					 }
  }

	function get_phc_id($data){
 	 $q=$this->db->query("Select * from phc where phc_code='$data'");

 	 if($q->num_rows() > 0 )
 	 {
 		 return true;
 	 }
 	 return false;
 }

 function add_rec_stock($a,$b,$c){
	$q=$this->db->query("update all_drugs set quantity=quantity+'$b' where drug_id='$a' and phc_code='$c'");
	$q1=$this->db->query("update stock_ledger set qty_added=(qty_added+'$b') where drug_id='$a' and phc_code='$c' and date(created_date)=CURDATE()");

	if($q)
	{
		return 1;
	}
	return 0;
}
function ack_rec_stock($a){
 $q=$this->db->query("update drugs_history set status=3 where hist_id='$a'");

 if($q)
 {
	 return 1;
 }
 return 0;
}

 function get_email($data){
		$q=$this->db->query("Select * from users where email='$data'");

		if( $q->num_rows() > 0 )
		{
			return true;
		}
		return false;
 }

 function get_doc_id($data){
	 $q=$this->db->query("Select * from doctor where doctor_id='$data'");

	 if( $q->num_rows() > 0 )
	 {
		 return true;
	 }
	 return false;
}

function get_lab_test($data)/*,$phc)*/{

	$q=$this->db->query("Select * from tests where test_name='$data'");	/*and phc_code='$phc'");*/

	if( $q->num_rows() > 0 )
	{
		return true;
	}
	return false;
}

function get_drug($data,$phc){
	$q=$this->db->query("Select * from all_drugs where drug_name='$data' and phc_code='$phc'");

	if( $q->num_rows() > 0 )
	{
		return true;
	}
	return false;
}


function get_alld($data,$rh){
	$q=$this->db->query("Select * from all_drugs where trig=1 and  phc_code='".$rh."' and drug_name like '%".$data."%' ");

	if( $q->num_rows() > 0 )
	{
		return $q->result_array();
	}
	return false;
}



function search_pat($data,$rh){
	$q=$this->db->query("Select * from patient_register where  (pat_no like '%".$data."%' OR pat_name like '%".$data."%' OR nrkid  like '%".$data."%') and rhc_id='".$rh."'  ");

	if( $q->num_rows() > 0 )
	{
		return $q->result_array();
	}
	return false;
}
function search_lab_pat($data,$rh){
	$q=$this->db->query("Select * from referred r,phc p where r.phc_id=p.phc_code and  (p.phc_name like '%".$data."%' OR r.op_file_no like '%".$data."%' OR r.pat_name like '%".$data."%' OR r.nrkid  like '%".$data."%') ");

	if( $q->num_rows() > 0 )
	{
		return $q->result_array();
	}
	return false;
}
function search_lab_pat_t($data,$rh){
	$q=$this->db->query("Select * from lab_patients where (pat_name like '%".$data."%' OR op_no like '%".$data."%' OR refer_id like '%".$data."%')");

	if( $q->num_rows() > 0 )
	{
		return $q->result_array();
	}
	return false;
}

function get_admin_email(){
	$query = $this->db->query("select * from users where role=1");

			return $query->result_array();

	}
	function get_incharge_email($id){
		$query = $this->db->query("select * from users where phc_code=".$id);

				return $query->result_array();

		}



}




?>
